<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following flow
 * of control:
 *
 * - This method should be static
 * - Check if the $_REQUEST content actually is the plugin name
 * - Run an admin referrer check to make sure it goes through authentication
 * - Verify the output of $_GET makes sense
 * - Repeat with other user roles. Best directly by using the links/query string parameters.
 * - Repeat things for multisite. Once for a single site in the network, once sitewide.
 *
 * This file may be updated more in future version of the Boilerplate; however, this is the
 * general skeleton and outline for how the file should work.
 *
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Plugin_Name
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
global $wpdb;
$cptName = 'faqs';


// if save_ff_database === true, delete all installation of Faq Fetch Plugin. 
if(!get_option('_ff_save_database')){
		// delete options db table data
		// template colors
		$optionsNames = array(

							'_ff_accordion_wrapper_max_width-square',
							'_ff_accordion_margin_bottom-square',
							'_ff_accordion_border_bottom_color-square',
							'_ff_accordion_border_bottom_width-square',
							'_ff_label_color-square',
							'_ff_label_padding-square',
							'_ff_label_background-square', 
							'_ff_label_font_size-square', 
							'_ff_label_border_radius-square',
							'_ff_label_background_hover-square', 
							'_ff_label_border_width-square', 
							'_ff_label_border_color-square', 
							'_ff_content_color-square', 
							'_ff_content_background-square', 
							'_ff_content_font_size-square', 
							'_ff_content_border_radius-square',
							'_ff_category_padding-square',
							'_ff_category_background-square',
							'_ff_category_color-square',
							'_ff_category_font_size-square',
							'_ff_accordion_margin_top-square',
						


							'_ff_search_container_max_width', 
							'_ff_search_field_border_width', 
							'_ff_search_field_border_color', 
							'_ff_search_field_padding',
							'_ff_search_field_border_radius', 
							'_ff_search_field_relative_top',
							'_ff_search_field_box_shadow',
							'_ff_search_field_bg_color', 
							'_ff_search_submit_bg_color', 
							'_ff_search_submit_color', 
							'_ff_search_submit_border_color', 
							'_ff_search_submit_border_width',
							'_ff_search_submit_padding',
							'_ff_search_submit_border_radius', 
							'_ff_search_submit_relative_top',
							'_ff_search_submit_line_height',
							'_ff_search_submit_hover_bg_color',
							'_ff_search_submit_hover_color', 
							'_ff_search_field_color',
							'_ff_search_field_line_height',
							'_ff_search_messages_color',
							'_ff_search_messages_font_size',

							'_ff_orderby',
							'_ff_order',

							'_ff_default_styles_ran_search_box',
							'_ff_default_styles_ran_accordion',

							'_ff_accordion_orderby',
							'_ff_accordion_order',
							'_ff_accordion_category',

							'_ff_email_address',
			
						);



				$tableOptions = $wpdb->prefix . 'options';

				foreach($optionsNames as $options_name){
						$optionsDeleteQuery = "DELETE FROM $tableOptions WHERE option_name='$options_name'";
						$wpdb->query($optionsDeleteQuery);
				}	
				
				
				// delete postmeta db table data
				
				$metaNames = array(	
						
						'_ff_count',
						'ff_video_url_field_meta_key',
					);
				
				
				$tableMeta = $wpdb->prefix . 'postmeta';

				
				foreach($metaNames as $meta_name){
						$metaDeleteQuery = "DELETE FROM $tableMeta WHERE meta_key='$meta_name'";
						$wpdb->query($metaDeleteQuery);
				}


				// delete posts db table data
				// Don't delete the Faqs post-type posts in Free version incase upgraded to premium		
				$postsNames = array(	
								
					'faqs',
					
				);


				$tablePosts = $wpdb->prefix . 'posts';

				foreach($postsNames as $posts_type){
						$postsDeleteQuery = "DELETE FROM $tablePosts WHERE post_type='$posts_type'";
						$wpdb->query($postsDeleteQuery);
				}


}