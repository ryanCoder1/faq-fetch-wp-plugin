<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin
 * @since             1.0.0
 * @package           Faq-Fetch 
 *
 * Plugin Name:       Faq Fetch
 * Plugin URI:        https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin
 * Description:       Retrieves all faq searches to organize for the best Faq awareness.
 * Version:           1.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.2
 * Author:            NewJourneyDesigns
 * Author URI:        https://www.newjourneydesigns.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       wp-faq-fetch
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'FAQ_FETCH_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-faq-fetch-activator.php
 */
function activate_faq_fetch_free() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-faq-fetch-activator.php';
	Faq_Fetch_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-faq-fetch-deactivator.php
 */
function deactivate_faq_fetch_free() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-faq-fetch-deactivator.php';
	Faq_Fetch_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_faq_fetch_free' );
register_deactivation_hook( __FILE__, 'deactivate_faq_fetch_free' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-faq-fetch.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_faq_fetch_free() {

	$plugin = new Faq_Fetch_Free();
	$plugin->run();

}




run_faq_fetch_free();
