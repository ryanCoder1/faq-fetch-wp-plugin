<?php

/** 
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin
 * @since      1.0.0
 *
 * @package    Faq_Fetch
 * @subpackage Faq_Fetch/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Faq_Fetch
 * @subpackage Faq_Fetch/public
 * @author     Ryan Lackey <ryanlackey1976@gmail.com>
 */
class Faq_Fetch_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $faq_fetch    The ID of this plugin.
	 */
	private $faq_fetch;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $faq_fetch       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $faq_fetch, $version ) {

		$this->faq_fetch = $faq_fetch;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Faq_Fetch_loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Faq_Fetch_loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->faq_fetch, plugin_dir_url( __FILE__ ) . 'css/faq-fetch-public.css', array(), $this->version, 'all' );
		
		
		wp_enqueue_style( $this->faq_fetch.'_square', plugin_dir_url( __FILE__ ) . 'css/faq-fetch-public-square.css', array(), $this->version, 'all' );

		wp_enqueue_style( 'font-search-google-public', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200' );


	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Faq_Fetch_loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Faq_Fetch_loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		$ajaxurl_arr = array('ajax_url' => admin_url('admin-ajax.php'),
							 'nonce' => wp_create_nonce('faq-fetch-ajax-nonce'));
		wp_enqueue_script( $this->faq_fetch, plugin_dir_url( __FILE__ ) . 'js/faq-fetch-public.js', array( 'jquery' ), $this->version, false );
		wp_localize_script($this->faq_fetch, 'ajaxurl_arr', $ajaxurl_arr);
	}


	/**
	 * register shortcodes
	 * 
	 * @since 1.0.0
	 */
	public function register_shortcodes() {
		add_shortcode( 'faq_fetch_search', array( $this, 'faq_fetch_search_shortcode' ));
		add_shortcode( 'faq_fetch_square', array( $this, 'faq_fetch_accordion_square_shortcode'));
	  }
	
	/**  
	*Register the column as sortable
	* 
	* @since 1.0.0
	*/
	function register_sortable_columns( $columns ) {
		$columns['count'] = 'Times Searched';
		return $columns;
	}
	
	/**
		 * add css styles in header for search box 
		 * Retrieve styles from database 
		 * 
		 * @since    1.0.0
		 */
		function adjust_search_box_css_styles_ff(){
		
			$data = array();

			$data['_ff_search_container_max_width'] = get_option('_ff_search_container_max_width') !== false ? sanitize_text_field(get_option('_ff_search_container_max_width')) : 725 ;
			$data['_ff_search_field_padding'] = get_option('_ff_search_field_padding') !== false ? sanitize_text_field(get_option('_ff_search_field_padding')) : 7 ;
			$data['_ff_search_field_border_radius'] = get_option('_ff_search_field_border_radius') !== false ? sanitize_text_field(get_option('_ff_search_field_border_radius')) : 0 ;
			$data['_ff_search_field_relative_top'] = get_option('_ff_search_field_relative_top') !== false ? sanitize_text_field(get_option('_ff_search_field_relative_top')) : 0 ;
			$data['_ff_search_field_box_shadow'] = get_option('_ff_search_field_box_shadow') !== false ? sanitize_text_field(get_option('_ff_search_field_box_shadow')) : 7 ;
			$data['_ff_search_submit_bg_color'] = get_option('_ff_search_submit_bg_color') !== false ? sanitize_text_field(get_option('_ff_search_submit_bg_color')) : '#153961' ;
			$data['_ff_search_submit_color'] = get_option('_ff_search_submit_color') !== false ? sanitize_text_field(get_option('_ff_search_submit_color')) : '#ffffff' ;
			$data['_ff_search_submit_padding'] = get_option('_ff_search_submit_padding') !== false ? sanitize_text_field(get_option('_ff_search_submit_padding')) : 7 ;
			$data['_ff_search_submit_border_radius'] = get_option('_ff_search_submit_border_radius') !== false ? sanitize_text_field(get_option('_ff_search_submit_border_radius')) : 0 ;
			$data['_ff_search_submit_relative_top'] = get_option('_ff_search_submit_relative_top') !== false ? sanitize_text_field(get_option('_ff_search_submit_relative_top')) : 0 ;
			$data['_ff_search_submit_line_height'] = get_option('_ff_search_submit_line_height') !== false ? sanitize_text_field(get_option('_ff_search_submit_line_height')) : 2 ;
			$data['_ff_search_submit_hover_bg_color'] = get_option('_ff_search_submit_hover_bg_color') !== false ? sanitize_text_field(get_option('_ff_search_submit_hover_bg_color')) : '#ffffff' ;
			$data['_ff_search_submit_hover_color'] = get_option('_ff_search_submit_hover_color') !== false ? sanitize_text_field(get_option('_ff_search_submit_hover_color')) : '#2868a4' ;
			$data['_ff_search_field_color'] = get_option('_ff_search_field_color') !== false ? sanitize_text_field(get_option('_ff_search_field_color')) : '#8f8a8a' ;
			$data['_ff_search_field_line_height'] = get_option('_ff_search_field_line_height') !== false ? sanitize_text_field(get_option('_ff_search_field_line_height')) : 2 ;
			$data['_ff_search_messages_color'] = get_option('_ff_search_messages_color') !== false ? sanitize_text_field(get_option('_ff_search_messages_color')) : '#8c8787' ;
			$data['_ff_search_messages_font_size'] = get_option('_ff_search_messages_font_size') !== false ? sanitize_text_field(get_option('_ff_search_messages_font_size')) : 16 ;
			$data['_ff_search_field_bg_color'] = get_option('_ff_search_field_bg_color') !== false ? sanitize_text_field(get_option('_ff_search_field_bg_color')) : '#ffffff' ;
		   
			
			$stylesArg = '';
		
		
				$dataKeys = array_keys($data);
				$dataValues = array_values($data);
			
			  
		$stylesArg = '<style type="text/css"> 
					.ff-search {
							max-width: '. ($dataKeys[0] === '_ff_search_container_max_width' ?  $dataValues[0].'px'  : '' ).' !important;
						}
					 .ff-search-field {
							
							padding: '. ($dataKeys[1] === '_ff_search_field_padding' ?   $dataValues[1].'px 0 '.$dataValues[1].'px 15px'  : '' ).' !important;
							border-radius: '.($dataKeys[2] === '_ff_search_field_border_radius' ?  $dataValues[2].'px 0 0 ' . $dataValues[2].'px'  : '' ).' !important;
							top: '. ($dataKeys[3] === '_ff_search_field_relative_top' ?  $dataValues[3].'px'  : '' ).' !important;
							box-shadow: '. ($dataKeys[4] === '_ff_search_field_box_shadow' ?  '0px 0px '. $dataValues[4].'px 1px rgba(0,0,0, .2)'  : '' ).' !important;
							-moz-box-shadow: '. ($dataKeys[4] === '_ff_search_field_box_shadow' ?  '0px 0px '. $dataValues[4].'px 1px rgba(0,0,0, .2)'  : '' ).' !important;
							-webkit-box-shadow: '. ($dataKeys[4] === '_ff_search_field_box_shadow' ?  '0px 0px '. $dataValues[4].'px 1px rgba(0,0,0, .2)'  : '' ).' !important;
						
						
						}
						
					.ff-search-submit {
							
							background-color: '. ($dataKeys[5] === '_ff_search_submit_bg_color' ?  $dataValues[5] : '' ).' !important;
							color: '. ($dataKeys[6] === '_ff_search_submit_color' ?  $dataValues[6]  : '' ).' !important;
							padding:'. ($dataKeys[7] === '_ff_search_submit_padding' ?  $dataValues[7].'px 0 '.$dataValues[7].'px 0px'   : '' ).' !important;
							border-radius:'. ($dataKeys[8] === '_ff_search_submit_border_radius' ? '0 ' .$dataValues[8].'px '.$dataValues[8].'px 0'   : '' ).' !important;
							top: '. ($dataKeys[9] === '_ff_search_submit_relative_top' ?  $dataValues[9].'px'  : '' ).' !important;
							line-height: '. ($dataKeys[10] === '_ff_search_submit_line_height' ?  $dataValues[10].'em'  : '' ).' !important;
						}
						
					
					.ff-search-submit:hover {
							background-color: '. ($dataKeys[11] === '_ff_search_submit_hover_bg_color' ?  $dataValues[11]  : '' ).' !important;
						}
						.ff-search-submit:hover > span {
							color: '. ($dataKeys[12] === '_ff_search_submit_hover_color' ?  $dataValues[12] : '') .' !important;
						}
					input.ff-search-field::placeholder {
							color: '. ($dataKeys[13] === '_ff_search_field_color' ?  $dataValues[13]  : '' ).' !important;
						}
					.ff-search-field {
							line-height: '. ($dataKeys[14] === '_ff_search_field_line_height' ?  $dataValues[14].'em'  : '' ).' !important;
					    }
					.ff-search-msg, .ff-search-msg-draft, .ff-search-msg-q-empty {
							color: '. ($dataKeys[15] === '_ff_search_messages_color' ?  $dataValues[15]  : '' ).' !important;
							font-size: '. ($dataKeys[16] === '_ff_search_messages_font_size' ?  $dataValues[16].'px'  : '' ).' !important;
						}
					input.ff-search-field {
							background-color: '. ($dataKeys[17] === '_ff_search_field_bg_color' ?  $dataValues[17]  : '' ).' !important;
							color: '. ($dataKeys[13] === '_ff_search_field_color' ?  $dataValues[13]  : '' ).' !important;
						}
				 </style>';
					// return to the head of the html document
					echo _e($stylesArg);


		}	
		/**
	 * create faq-fetch post_type search box shortcode
	 * 
	 * @since 1.0.0
	 */
	function faq_fetch_search_shortcode() {
		ob_start();
		?>
		<section class="faq-fetch-search">
			<div class="ff-search">
				
				<form  method="post" class="ff-search-form" >
					<label>
						<input type="text" id="ff-search-field" class="ff-search-field" placeholder="<?php echo esc_attr_x( 'Search FAQs', 'placeholder' ); ?>" value="<?php echo get_search_query(); ?>" name="q" />
						<button type="submit" class="ff-search-submit" ><span class="material-symbols-outlined ff-search-submit-i-admin">search</span></button>
					</label>
					<input type="hidden" id="ff-search-post-type" class="ff-search-post-type" name="post_type" value="faqs" />
				</form>
				<div class="ff-search-msg">This FaQ question has no match so it will be reviewed. Please give us time to answer and check back soon.</div>
				<div class="ff-search-msg-draft">This FaQ question is popular! We're looking to get an answer quick for this. Check back soon.</div>
				<div class="ff-search-msg-q-empty">This FaQ question is empty. Please type in a question.</div>
			</div>
		</search>
		<?php
		$output = ob_get_clean();
		return $output;
	}
	/**
		 * add css styles in header for accordion styles
		 * Retrieve styles from database 
		 * 
		 * @since    1.0.0
		 */
		function adjust_accordion_css_styles_ff(){
			
			$data = array();

			
			$data['_ff_accordion_wrapper_max_width-square'] = get_option('_ff_accordion_wrapper_max_width-square') !== false ?    sanitize_text_field(get_option('_ff_accordion_wrapper_max_width-square'))   :  780   ;
			$data['_ff_accordion_margin_bottom-square'] = get_option('_ff_accordion_margin_bottom-square') !== false ?    sanitize_text_field(get_option('_ff_accordion_margin_bottom-square'))   :  0   ;
			$data['_ff_accordion_border_bottom_color-square'] = get_option('_ff_accordion_border_bottom_color-square') !== false ?    sanitize_text_field(get_option('_ff_accordion_border_bottom_color-square'))   :  '#ffffff'  ;
			$data['_ff_accordion_border_bottom_width-square'] = get_option('_ff_accordion_border_bottom_width-square') !== false ?    sanitize_text_field(get_option('_ff_accordion_border_bottom_width-square'))   : 2  ;
			$data['_ff_label_color-square'] = get_option('_ff_label_color-square') !== false ?    sanitize_text_field(get_option('_ff_label_color-square'))   : '#ffffff' ;
			$data['_ff_label_padding-square'] = get_option('_ff_label_padding-square') !== false ?    sanitize_text_field(get_option('_ff_label_padding-square'))   : 30 ;
			$data['_ff_label_background-square'] = get_option('_ff_label_background-square') !== false ?    sanitize_text_field(get_option('_ff_label_background-square'))   :  '#0a365c' ;
			$data['_ff_label_font_size-square'] = get_option('_ff_label_font_size-square') !== false ?    sanitize_text_field(get_option('_ff_label_font_size-square'))   : 22 ;
			$data['_ff_label_border_color-square'] = get_option('_ff_label_border_color-square') !== false ?    sanitize_text_field(get_option('_ff_label_border_color-square'))   : '' ;
			$data['_ff_label_border_width-square'] = get_option('_ff_label_border_width-square') !== false ?    sanitize_text_field(get_option('_ff_label_border_width-square'))   : 0 ;
			$data['_ff_label_border_radius-square'] = get_option('_ff_label_border_radius-square') !== false ?    sanitize_text_field(get_option('_ff_label_border_radius-square'))   : 0 ;
			$data['_ff_label_background_hover-square'] = get_option('_ff_label_background_hover-square') !== false ?    sanitize_text_field(get_option('_ff_label_background_hover-square'))   :  '#1a4d75' ;
			$data['_ff_content_color-square'] = get_option('_ff_content_color-square') !== false ?    sanitize_text_field(get_option('_ff_content_color-square'))   :   '#d1d1d1' ;
			$data['_ff_content_font_size-square'] = get_option('_ff_content_font_size-square') !== false ?    sanitize_text_field(get_option('_ff_content_font_size-square'))   :   19 ;
			$data['_ff_content_background-square'] = get_option('_ff_content_background-square') !== false ?    sanitize_text_field(get_option('_ff_content_background-square'))   :   '#083359' ;
			$data['_ff_content_border_radius-square'] = get_option('_ff_content_border_radius-square') !== false ?    sanitize_text_field(get_option('_ff_content_border_radius-square'))   :  0 ;
			$data['_ff_accordion_margin_top-square'] = get_option('_ff_accordion_margin_top-square') !== false ?    sanitize_text_field(get_option('_ff_accordion_margin_top-square'))   :  20 ;
			$data['_ff_category_padding-square'] = get_option('_ff_category_padding-square') !== false ?    sanitize_text_field(get_option('_ff_category_padding-square'))   :  10 ;
			$data['_ff_category_background-square'] = get_option('_ff_category_background-square') !== false ?    sanitize_text_field(get_option('_ff_category_background-square'))   :  '#113f69' ;
			$data['_ff_category_color-square'] = get_option('_ff_category_color-square') !== false ?    sanitize_text_field(get_option('_ff_category_color-square'))   :   '#a7b0b4' ;
			$data['_ff_category_font_size-square'] = get_option('_ff_category_font_size-square') !== false ?    sanitize_text_field(get_option('_ff_category_font_size-square'))   :   16 ;
			$data['_ff_category_border_radius-square'] = get_option('_ff_category_border_radius-square') !== false ?    sanitize_text_field(get_option('_ff_category_border_radius-square'))   :  0 ;
			
			$stylesArg = '';
		
			$dataKeys = array_keys($data);
			$dataValues = array_values($data);
		
			$hover_bg_init = $dataValues[11] === 'transparent' ? true : false;
		    $hover_bg_style = 	($hover_bg_init) ? $dataValues[6] : $dataValues[11];
		
			
		$stylesArg = '<style type="text/css">
				.ff-accordion-wrapper {
						max-width: '. ($dataKeys[0] === '_ff_accordion_wrapper_max_width-square' ?  $dataValues[0].'px'  : '' ).' ;
					}
				.ff-accordion {
						margin: '. ($dataKeys[1] === '_ff_accordion_margin_bottom-square' ?  $dataValues[1].'px 0px'  : '' ).' !important;
						border-bottom-color: '. ($dataKeys[2] === '_ff_accordion_border_bottom_color-square' ?  $dataValues[2]  : '' ).' !important;
						border-bottom-width: '. ($dataKeys[3] === '_ff_accordion_border_bottom_width-square' ?  $dataValues[3].'px'  : '' ).' !important;
					}
					
				.ff-accordion-label {
						color: '. ($dataKeys[4] === '_ff_label_color-square' ?  $dataValues[4]  : '' ).' !important;
						padding: '. ($dataKeys[5] === '_ff_label_padding-square' ?   $dataValues[5].'px 15px '. $dataValues[5].'px 15px' : '' ).' !important;
						background-color: '. ($dataKeys[6] === '_ff_label_background-square' ?  $dataValues[6]  : '' ).' !important;
						border-color: '. ($dataKeys[8] === '_ff_label_border_color-square' ?  $dataValues[8]  : '' ).' !important;
						border-width: '. ($dataKeys[9] === '_ff_label_border_width-square' ?  $dataValues[9].'px'  : '' ).' !important;
						border-radius: '. ($dataKeys[10] === '_ff_label_border_radius-square' ?  $dataValues[10].'px'  : '' ).' !important;
					}
				.ff-accordion-label-content > span:first-child, .ff-accordion-label::after{
						font-size: '. ($dataKeys[7] === '_ff_label_font_size-square' ?  $dataValues[7].'px'  : '' ).' !important;
					}	
				.ff-accordion-label:hover { 
						background-color: '. ($dataKeys[11] === '_ff_label_background_hover-square'  ?  $hover_bg_style  : '' ).' !important;
					}
				.ff-accordion-content {
						color: '. ($dataKeys[12] === '_ff_content_color-square' ?  $dataValues[12]  : '' ).' !important;
						font-size: '. ($dataKeys[13] === '_ff_content_font_size-square' ?  $dataValues[13].'px'  : '' ).' !important;
						background-color: '. ($dataKeys[14] === '_ff_content_background-square' ?  $dataValues[14]  : '' ).' !important;
						border-radius: '.  ($dataKeys[15] === '_ff_content_border_radius-square' ?  $dataValues[15].'px' : '') .' !important;
					}
				
				.ff-accordion-wrapper {
						margin-top: '. ($dataKeys[16] === '_ff_accordion_margin_top-square' ?  $dataValues[16].'px'  : '' ).' !important;
					}
				.ff-accordion-category {
						padding: '. ($dataKeys[17] === '_ff_category_padding-square' ?  $dataValues[17].'px 0px '. $dataValues[17].'px 15px'  : '' ).' !important;
						background-color: '. ($dataKeys[18] === '_ff_category_background-square' ?  $dataValues[18]  : '' ).' !important;
						color: '. ($dataKeys[19] === '_ff_category_color-square' ?  $dataValues[19]  : '' ).' !important;
						font-size: '. ($dataKeys[20] === '_ff_category_font_size-square' ?  $dataValues[20].'px'  : '' ).' !important;
						border-radius: '. ($dataKeys[21] === '_ff_category_border_radius-square' ?  $dataValues[21].'px'  : '' ).' !important;
					}
				</style> ';
					// return to the head of the html document
					echo _e($stylesArg);
		}	
	
	/**
		 * SHORTCODE FOR ACCORDION FAQ OUTPUT
		 * param = order,
		 * param = orderby
		 * 
		 * @since    1.0.0
		 */
		function faq_fetch_accordion_square_shortcode($atts) {
			ob_start();

			  // Default attribute values
			$atts = shortcode_atts( array(
				'order' => 'ASC',
				'orderby' => 'date',
				'faq_category' => 1,
			), $atts );


			
			$order =   $atts['order'];
			$orderby =  $atts['orderby'];
			// In this free version $faq_category always 0 for no category selection. 
			$faq_category = 0; 

		 if($orderby === '_ff_count'){

			$query_args = array(
				'post_type' => 'faqs',
				'posts_per_page' => -1, // to retrieve all posts
				'order' => $order,
				'meta_key' => $orderby,
				'orderby' => 'meta_value_num',
			  );
			  
			}else{

			$query_args = array(
				'post_type' => 'faqs',
				'posts_per_page' => -1, // to retrieve all posts
				'order' => $order,
				'orderby' => $orderby,
			  );

			}

			/**
			 * Get categories that only exist in post_type 'faqs' and fill in with the matching posts
			 */
			// Get the terms for the "faq category" taxonomy
			// set taxonomy term arguments
			$args = array(
				'taxonomy' => 'faq-categories', // taxonomy name
				'order' => $order,
				
				'hide_empty' => true // hide empty terms
			);
			
			// get taxonomy terms
			$terms = get_terms( $args );
		
			// loop through terms and get posts
			 foreach( $terms as $term ) {
			
				
				// set up query arguments
				// In this free version $faq_category always 0 for no category selection. 
			  if($faq_category){
					$query_args = array(
					'post_type' => 'faqs', // post type
					'posts_per_page' => -1, // number of posts to show
					
					'tax_query' => array(
						array(
						'taxonomy' => 'faq-categories', // taxonomy name
						'field' => 'term_id',
						'terms' => $term->term_id,
						)
					)
					);
				}
				// run query with either of the $query_args generated
				$faqs_query = new WP_Query( $query_args );


					

			  $string = '';
			  if(isset($_REQUEST['data']) && !empty($_REQUEST['data'])){
				$qString =  $_REQUEST['data']['q'];
				$array = explode( ' ',  $qString);
				$string = implode( '-', $array );
			}
			
			
		
			?>
				<section class="faq-fetch-square">
				
					<div class="ff-accordion-wrapper">
						<?php
						// In this free version $faq_category always 0 for no category selection. 
							if($faq_category){ ?>
							<p class="ff-accordion-category">
								<?php esc_html($term->name); ?>
							</p>
						<?php
						}
						if($faqs_query->have_posts()){
							$i = 0;
							while($faqs_query->have_posts()){
							  $faqs_query->the_post(); 
								$i++;

								$arrayTitle = explode( ' ',  get_the_title());
								$stringTitle = implode( '-', $arrayTitle );
								$stringTitle = strtolower($stringTitle);
						
								?>
								<div  class="ff-accordion">
									<input type="checkbox" name="radio-a" id="<?php echo $stringTitle; ?>">
									<label class="ff-accordion-label" for="<?php echo $stringTitle; ?>">
										<p class="ff-accordion-label-content">
											<span>
												<?php esc_html(the_title()); ?>
											</span>
										<br>
										<br>
										 <!-- In this free version $faq_category always 0 for no category selection.  -->
											<span>
												 <?php 
												//  echo wp_trim_words( get_the_content(), 6, '...' ); 
												 ?>
											</span> 
										</p>
									</label>
									<div class="ff-accordion-content">
									<div class="ff-accordion-content-text"><?php echo esc_html(the_content()); ?></div>
										<?php if(the_post_thumbnail()){ 
											
											?>

										<div class="ff-accordion-content-thumbnail"><?php esc_url(the_post_thumbnail('medium')); ?></div>
										<?php
										}
										?>
											<?php
											// Retrieving current value of the video URL from database
											$video = get_post_meta( get_the_ID(), 'ff_video_url_field_meta_key', true );
										
											 if($video){ 
												
											echo $video; 
									  		
											 }
										?>

									</div>
								</div>
								
							<?php 
							  }
							}
							if(!$faq_category){ 
								break;
							}
						 }
							wp_reset_postdata(); // Reset post data query after the loop.
						?>
					</div>	
					
				</section>
			<?php
			$output = ob_get_clean();
			return $output. '</div></div>';
		}



	// Hook into the WordPress search results to check for duplicate titles in custom post type
		function search_results_duplicates_check_ff(  ) {
			
			if (!isset($_POST['data']['nonce']) || !wp_verify_nonce($_POST['data']['nonce'], 'faq-fetch-ajax-nonce')) {
				wp_die(-1);
			}
			
			
			global $wpdb;
			
			$q =  sanitize_text_field( $_POST['data']['q']);
			 // Get the search query
			 $search = $q;
			 // Get the custom post type
			 $post_type = 'faqs';

			 $new = 0;
			 $postID = '';
			 $titleMatch = '';
			 $draftCount = 0;
			 $draftResults = '';
			// Check if the query is a search query
			  if( !empty($q) ) {
				$draft = 'draft';
				$trash = 'trash';
				$publish = 'publish';
			
						// Query the database to check for close to string titles and retrieve the ID, post_title
						$results = $this->ff_db_query_faq_close_matches( $post_type, $publish, $search );

							$count = false;
							
							// Loop through results and echo post ID and title
							if ($results ) {
								foreach ($results as $result) {
									$postID = $result->ID;
									$titleMatch = $result->post_title;
									
								}
							} else {
									$count = true;
							}
					
	
							// if $results > 0 meaning a query db match and as a publish
						if( count($results) > 0 ) {
		
									
										// get old post meta with postID  / Count = Times Questioned
										$old = get_post_meta( $postID, '_ff_count', true );
											// if $old value is empty, make it 1 else increment by 1
											if(empty($old)){
												$new = 1;
											}else{
												$new = $old + 1;
											}
											// use the $new value for the update post meta on the current postID duplicate
											update_post_meta( $postID, '_ff_count', $new );

											// add '-' between each word in search for HTML element id controls
											$arrayTitle = explode( ' ',  $titleMatch);
											$stringTitle = implode( '-', $arrayTitle );
											$stringTitle = strtolower($stringTitle);

											// create array and send data back when search is duplicate
											$data = array(
												'checkID' => $stringTitle,
												'success' => 'active'
											
											);
											wp_send_json($data);
											
								
						}else{
								//Query the database to see if post_title is a draft and not trash / return (int) value
								$draftResults = $this->ff_db_query_faq_draft_count( $post_type, $draft, $trash, $search );
							// if draft match in query db 
								if( count($draftResults) > 0){									
									
									$postIDDraft = '';											

									// Loop through results and echo post ID 
									if ($draftResults) {
										foreach ($draftResults as $result) {
											$postIDDraft = $result->ID;	
										}
									} 

										// get old post meta with postIDDraft  / Count = Times Questioned
										$old = get_post_meta( $postIDDraft, '_ff_count', true );
											
										if(empty($old)){
												$new = 1;
											}else{
												$new = $old + 1;
											} 
											// use the $new value for the update post meta on the current postID duplicate
											update_post_meta( $postIDDraft, '_ff_count', sanitize_text_field($new) );
				
											// create array and send data back when search is duplicate as draft
											$dataDupDraft = array(
												'success' => 'active-dup-draft'
											);
											wp_send_json($dataDupDraft);
											
										}else{

												//Insert the post into the database	
												$faq_post_id = $this->ff_db_insert_faq( $search );
												
												//Insert was successful 
												if( !is_wp_error($faq_post_id) ) {

													
													$new = 1;
													
													// use the $new value for the update post meta on the current postID duplicate
													update_post_meta( $faq_post_id, '_ff_count',  sanitize_text_field($new)  );

													// function to send email for new faq question
													$send_email = $this->ff_send_new_faq_email( $search );
													
													// create array and send data back when search has first result add to database
													$dataInsert = array(
														'checkID' => $stringTitle,
														'success' => 'not-active',
														'email' => $send_email,
													);
													wp_send_json($dataInsert);
													
												}
											}
										}
								
							}else{
								// create array and send data back when search is empty search
								$data = array(
									'success' => 'q-empty'
								);
								wp_send_json($data);
							}
							wp_die();
		
		}



		/**
		 * Query the database to check for close to string titles and retrieve the ID, post_title
		 * 
		 * @return  results 
		 * 
		 * @since    1.0.0
		 */
		private function ff_db_query_faq_close_matches( $post_type, $publish, $search ){
			
			global $wpdb;
			// post_title (faq search) all lower case search since WHERE LIKE case sensitive
			return $wpdb->get_results( 
				$wpdb->prepare("SELECT ID, post_title FROM $wpdb->posts
				 WHERE post_type = %s AND post_status = %s AND LOWER(post_title) LIKE %s", 
				 $post_type, 
				 $publish,
				 '%' . $wpdb->esc_like( strtolower( $search ) ) . '%'));
			
		}


		/**
		 * Query the database to see if post_title is a draft and not trash
		 * 
		 * @return  (int) result from database 
		 * 
		 * @since    1.0.0
		 * 
		 */
		private function ff_db_query_faq_draft_count( $post_type, $draft, $trash, $search ){
			
			global $wpdb;

			return $wpdb->get_results( 
				    $wpdb->prepare("SELECT ID, post_title FROM $wpdb->posts
						WHERE post_type = %s AND post_status = %s AND post_status != %s AND LOWER(post_title) LIKE %s", 
						$post_type, 
						$draft,
						$trash,
						'%' . $wpdb->esc_like( strtolower( $search ) ) . '%'));

		}
		/**
		 * Insert the new faq into the database
		 * 
		 * @return  results 
		 * 
		 * @since    1.0.0
		 */
		private function ff_db_insert_faq( $search ){
			

			$new_faq = array( 
				'post_title' => $search,
				'post_status' => 'draft', 
				'post_type' => 'faqs'
				);
			
				//Insert the post into the database
				return wp_insert_post( $new_faq );
			
		}

		/**
		 * Send email to designated email for new faq questions 
		 * 
		 * @return  email sent success
		 * 
		 * @since    1.0.0
		 * 
		 */
		private function ff_send_new_faq_email( $search ){

			$linkFromEmail = get_admin_url(  );
			$webLink = '<a href="'.$linkFromEmail.'edit.php?post_type=faqs">Link to FaQ Fetch Dashboard</a>';
			// Replace "admin_username" with the actual username of the admin user you want to send an email to
				$to =  get_option('_ff_email_address');

				$subject = 'New FaQ from Website';

				$message = '<div>';
				$message .= '<h4>New FaQ from website</h4>';
				$message .= '<h2>'. $search .'</h2>';
				$message .= '<p>Make sure to visit the website and publish, answer, and add faq category. </p>';
				$message .= $webLink;	
				$message .= '<p>Courtesy of the FaQ Fetch Plugin </p>';									
				$message .=  '</div>';
				
				
			

				$headers = [
				'Content-Type: text/html; charset=UTF-8',
				'From: Website <noreply@website.com>'
				];

				// Send email using wp_mail function
				return  wp_mail( $to, $subject, stripslashes($message), $headers );

		}


	}
