(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	
	//   
			   
	// 			</style>
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	jQuery(document).ready(function($) {



		$('.ff-accordion-admin-label').mouseenter(function(){
							
			$(this).css({'background-color': bg_hover });

		});
		$('.ff-accordion-admin-label').mouseleave(function(){
		
			$(this).css({'background-color': bg});

	});

	// add class to video as php code can't reach the class designation
	$(".ff-accordion-content > iframe").addClass('ff-accordion-content-video');
	

	
		$('.ff-search-msg').hide();
		$('.ff-search-msg-draft').hide();
	
		$('.ff-search-submit').click(function(e) {
			e.preventDefault();
			var user_input = $('#ff-search-field').val();
			var user_input_post_type = $('#ff-search-post-type').val();
			
				
			$.ajax({
				url: ajaxurl_arr.ajax_url,
				type: 'POST',
				data: {
					'action': 'search_results_duplicates_check_ff',
					'data': {q : user_input, post_type : user_input_post_type, nonce : ajaxurl_arr.nonce}
				},
				success:function(data) {

					$('#ff-search-field').val('');

					if(data.success === 'active'){
						// if search is published/active check the id element check box
						$('#' + data.checkID).prop('checked', true);
						// scroll down animate to accordion element
						$('html, body').animate({
							scrollTop: $('#' + data.checkID).offset().top
						},1000);
					}
					if(data.success === 'not-active'){
						// if search is published/active check the id element check box
						$('.ff-search-msg').fadeIn(250).delay(6000).fadeOut(250);
				
					}
					if(data.success === 'active-dup-draft'){
						// if search is duplicate/draft check the id element check box
						$('.ff-search-msg-draft').fadeIn(250).delay(6000).fadeOut(250);
				
					}
					if(data.success === 'q-empty'){
						// if search is duplicate/draft check the id element check box
						$('.ff-search-msg-q-empty').fadeIn(250).delay(6000).fadeOut(250);
				
					}
				},
				error: function(errorThrown){
					console.log(errorThrown);
				}
			});
		
		});

	});



})( jQuery );
