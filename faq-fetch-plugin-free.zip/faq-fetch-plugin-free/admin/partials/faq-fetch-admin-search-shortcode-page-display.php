<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin
 * @since      1.0.0
 *
 * @package    Faq_Fetch
 * @subpackage Faq_Fetch/admin/partials
 */



// when plugin is uploaded to site, set the shortcode atts to an initial variable. 
 $order = get_option('_ff_accordion_order') === false ? 'ASC'  : esc_html(get_option('_ff_accordion_order'));
 $orderby =  get_option('_ff_accordion_orderby') === false ? 'date' : esc_html(get_option('_ff_accordion_orderby'));
 $faq_category =  get_option('_ff_accordion_category') === false ?  0 :'on';


if(isset($_POST['_ff_accordion_choice'])){

  $faq_category = (!empty($_POST['faq_category']) && $_POST['faq_category'] === 'on') ? 'on' : 0; 
 


  update_option('_ff_accordion_order', esc_html($_POST['order']));
  update_option('_ff_accordion_orderby', esc_html($_POST['order_by']));
  update_option('_ff_accordion_category', $faq_category);
 
  
 
  $order = get_option('_ff_accordion_order') !== 'ASC' ? esc_html(get_option('_ff_accordion_order')) : 'ASC';
  $orderby =  get_option('_ff_accordion_orderby') !== 'date' ? esc_html(get_option('_ff_accordion_orderby')) : 'date';


}
if(isset($_POST['_ff_email_submit'])){

  $email_address = ($_POST['_ff_email_address'] !== null) ? $_POST['_ff_email_address'] : '';
  update_option('_ff_email_address', sanitize_email($email_address));
}




?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="faq-fetch-add-search-container">
    <h1 class="faq-fetch-add-search-header">FaQ Fetch Plugin</h1>
   <div class="faq-fetch-add-email-description">
    <form class="faq-fetch-add-email-form" action="" method="post" >
    <p class="faq-fetch-add-email-info">
        
            This Plugin sends emails to a given email address to show when a new FaQ is asked.  Faq Fetch Plugin doesn't have the 
            setup to connect to an email SMTP service. Unless you have you're own email plugin you use then I suggest WP MAIL SMTP for easy setup of emails.
    </p>
     <h3 class="faq-fetch-add-email-h3">Send emails to</h3>
     
    
      <input type="email" class="faq-fetch-add-email-input" name="_ff_email_address" placeholder="Add email" value="<?php echo get_option('_ff_email_address'); ?>" validate="required:true">
      <div>
       <input class="faq-fetch-add-email-btn" type="submit" name="_ff_email_submit" value="Save email address"/>
      </div>
    </form> 
   </div>
 
    <p class="faq-fetch-add-search-description">
        
            The accordion shortcode is generated and saved on this page and can be adjusted with multiple outputs.  There is a search box shortcode constant for
            the Plugin. Please copy and paste shortcodes where needed.  
       
    </p>
    <!-- <h2 class="faq-fetch-add-search-page">Add Search Shortcode</h2> -->
    <div class="faq-fetch-add-search-shortcode">
      <form class="faq-fetch-add-accordion-form" action="" method="post" >
        <p class="faq-fetch-add-search-description">
            
                Make shortcode for accordion 
            
        </p>
        <div>
          
          <h3 class="faq-fetch-add-accordion-h3">Use faq categories?</h3>
            <div class="faq-fetch-add-checkbox-wrapper ff-scheme-with-premium-blank ">
           
              <label class="switch">
            
              <input type='hidden' value='0' name='faq_category'>
              <!-- keep chckbox unchecked all the time in Free Version  -->
              <input type="checkbox" class="faq-fetch-add-checkbox" name="faq_category" <?php echo get_option('_ff_accordion_category') === 'on' ? '' : '' ?>>
                <span class="slider round"></span>
                <p id="showCategory">Show</p>
              </label><span class="ff-scheme-with-premium"> with premium</span>
            
            </div>
            <div class="faq-fetch-add-order-by-wrapper">
              <h3 class="faq-fetch-add-accordion-h3" id="faq-fetch-add-accordion-h3">Order by</h3>
              <div id="orderBySelect">
                <select class="faq-fetch-add-accordion-select" id="faq-fetch-add-accordion-select" name="order_by">
                  <option value="date">Choose Order by</option>
                  <option value="ID">ID</option>
                  <option value="title">Title</option>
                  <option value="date">Date</option>
                  <option value="_ff_count">Times Searched</option>
                </select>
              </div>
            </div>
            <div class="faq-fetch-add-order-wrapper">
              <h3 class="faq-fetch-add-accordion-h3">Order</h3>
              <div>
                <select class="faq-fetch-add-accordion-select" name="order">
                  <option value="ASC">Choose Order</option>
                  <option value="ASC">Ascending</option>
                  <option value="DESC">Descending</option>
                </select>
              </div>
            </div>
            <br>
            <div>
              <input class="faq-fetch-add-accordion-btn" type="submit" name="_ff_accordion_choice" value="Make accordion shortcode"/>
            </div>
            <br>
            <div>
            <div class="faq-fetch-add-search-active">
              <div class="faq-fetch-add-search-description">
                  <span>
                      Active shortcode for accordion
                  </span>

                  <span class="faq-fetch-add-accordion-copy">Copied</span>
              </div>
              <input 
                id="faq-fetch-add-accordion-input" 
                class="faq-fetch-add-accordion-input"  
                type="text" 
                value="[faq_fetch_square order='<?php echo $order; ?>' orderby='<?php echo $orderby; ?>' faq_category='0']"
                readonly/>
              </div>
            </div>
         
          </form>

        </div>
   
  </div>

  <div class="faq-fetch-add-search-shortcode">
        
        <div class="faq-fetch-add-search-description">
            <span>
                Active shortcode for search box
            </span>
            <span class="faq-fetch-add-search-copy">Copied</span>
        </div>

        <div class="faq-fetch-add-search-active">
           <input 
           id="faq-fetch-add-search-input" 
           class="faq-fetch-add-search-input"  
           type="text" 
           value="[faq_fetch_search]" 
           readonly/>
        </div>
   
  </div>

</div>