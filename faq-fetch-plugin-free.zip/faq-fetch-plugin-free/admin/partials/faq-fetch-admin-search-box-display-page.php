<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin
 * @since      1.0.0
 *
 * @package    Faq_Fetch
 * @subpackage Faq_Fetch/admin/partials
 */
// search box default styles
// This file should primarily consist of HTML with a little bit of PHP.

if(isset($_POST['_ff_search-box'])){

    update_option('_ff_search_container_max_width', sanitize_text_field( $_POST['_ff_search_container_max_width']));
    update_option('_ff_search_field_padding', sanitize_text_field( $_POST['_ff_search_field_padding']));
    update_option('_ff_search_field_border_radius', sanitize_text_field( $_POST['_ff_search_field_border_radius']));
    update_option('_ff_search_field_relative_top', sanitize_text_field( $_POST['_ff_search_field_relative_top']));
    update_option('_ff_search_field_box_shadow', sanitize_text_field( $_POST['_ff_search_field_box_shadow']));
    update_option('_ff_search_field_bg_color', sanitize_text_field( $_POST['_ff_search_field_bg_color']));
    update_option('_ff_search_submit_bg_color', sanitize_text_field( $_POST['_ff_search_submit_bg_color']));
    update_option('_ff_search_submit_color', sanitize_text_field( $_POST['_ff_search_submit_color']));
    update_option('_ff_search_submit_padding', sanitize_text_field( $_POST['_ff_search_submit_padding']));
    update_option('_ff_search_submit_border_radius', sanitize_text_field( $_POST['_ff_search_submit_border_radius']));
    update_option('_ff_search_submit_relative_top', sanitize_text_field( $_POST['_ff_search_submit_relative_top']));
    update_option('_ff_search_submit_line_height', sanitize_text_field( $_POST['_ff_search_submit_line_height']));
    update_option('_ff_search_submit_hover_bg_color', sanitize_text_field( $_POST['_ff_search_submit_hover_bg_color']));
    update_option('_ff_search_submit_hover_color', sanitize_text_field( $_POST['_ff_search_submit_hover_color']));
    update_option('_ff_search_field_color', sanitize_text_field( $_POST['_ff_search_field_color']));
    update_option('_ff_search_field_line_height', sanitize_text_field( $_POST['_ff_search_field_line_height']));
    update_option('_ff_search_messages_color', sanitize_text_field( $_POST['_ff_search_messages_color']));
    update_option('_ff_search_messages_font_size', sanitize_text_field( $_POST['_ff_search_messages_font_size']));


  // stop default styles from running
  update_option('_ff_default_styles_ran_search_box', true);

}

if(!esc_html(get_option('_ff_default_styles_ran_search_box'))){


    update_option('_ff_search_container_max_width', 725);
    update_option('_ff_search_field_padding', 7);
    update_option('_ff_search_field_border_radius', 0);
    update_option('_ff_search_field_relative_top', 0);
    update_option('_ff_search_field_box_shadow', 7);
    update_option('_ff_search_field_bg_color', '#ffffff');
    update_option('_ff_search_submit_bg_color', '#153961');
    update_option('_ff_search_submit_color', '#ffffff');
    update_option('_ff_search_submit_padding', 7);
    update_option('_ff_search_submit_border_radius', 0);
    update_option('_ff_search_submit_relative_top', 0);
    update_option('_ff_search_submit_line_height', 2);
    update_option('_ff_search_submit_hover_bg_color','#ffffff');
    update_option('_ff_search_submit_hover_color', '#2868a4');
    update_option('_ff_search_field_color','#8f8a8a' );
    update_option('_ff_search_field_line_height',2 );
    update_option('_ff_search_messages_color', '#8c8787');
    update_option('_ff_search_messages_font_size', 18);



    // stop default styles from running
    update_option('_ff_default_styles_ran_search_box', true);


}



?>


<div class="ff-search-outside-container">
<!-- The container for grid css setup -->
<div class="ff-search-box-scheme-container">


<div class="ff-search-box-scheme-form-wrapper ff-search-box-scheme-left">
  <h1> Search box scheme </h1>
   <form method="post" action="" class="ff-search-box-scheme-form ff-scheme-form" >
     <br>
          <h4>Styles to choose</h4> 
          <div>
              <label>Container max width</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_container_max_width" data-field="Max_width"  min="250" max="1080"   value="<?php echo esc_html(get_option('_ff_search_container_max_width'));  ?>" >
            </div>
            <div>
              <label>Field padding</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_field_padding" data-field="Field_padding"  min="0" max="40"   value="<?php echo esc_html(get_option('_ff_search_field_padding'));  ?>" >
            </div>
            <div>
              <label>Field border radius</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_field_border_radius" data-field="Field_border_radius" min="0" max="50"  value="<?php echo esc_html(get_option('_ff_search_field_border_radius'));  ?>" >
            </div>
            <div>
              <label>Field up / down</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_field_relative_top" data-field="Field_relative_top" min="-15" max="15"  value="<?php echo esc_html(get_option('_ff_search_field_relative_top'));  ?>" >
            </div>
            <div>
              <label>Field box shadow</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_field_box_shadow" data-field="Field_box_shadow"  min="0" max="40"  value="<?php echo esc_html(get_option('_ff_search_field_box_shadow'));  ?>" >
            </div>
            <div>
              <label>Field text color</label>
              <input type="color" class="ff-search-box-scheme-form-control" name="_ff_search_field_color" data-field="Field_color" value="<?php echo esc_html(get_option('_ff_search_field_color'));  ?>" >
            </div>
            <div>
              <label>Field background color</label>
              <input type="color" class="ff-search-box-scheme-form-control" name="_ff_search_field_bg_color" data-field="Field_bg_color"  value="<?php echo esc_html(get_option('_ff_search_field_bg_color'));  ?>" >
            </div>
            <div>
              <label>Field line height</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_field_line_height" data-field="Field_line_height" min="1" max="2" step=".1"   value="<?php echo esc_html(get_option('_ff_search_field_line_height'));  ?>" >
            </div>
            <div>
              <label>Button bg color</label><span class="ff-search-box-reading"></span>
              <input type="color" id="ff-search-submit-bg"  class="ff-search-box-scheme-form-control" name="_ff_search_submit_bg_color" data-field="Submit_bg_color"  value="<?php echo esc_html(get_option('_ff_search_submit_bg_color'));  ?>" >
            </div>
            <div>
              <label>Button text color</label>
              <input type="color" id="ff-search-submit-text" class="ff-search-box-scheme-form-control" name="_ff_search_submit_color" data-field="Submit_color"  value="<?php echo esc_html(get_option('_ff_search_submit_color'));  ?>" >
            </div>
          
            <div>
              <label>Button padding</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_submit_padding" data-field="Submit_padding" min="0" max="50"  value="<?php echo esc_html(get_option('_ff_search_submit_padding'));  ?>" >
            </div>
            <div>
              <label>Button border radius</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_submit_border_radius" data-field="Submit_border_radius" min="0" max="50"  value="<?php echo esc_html(get_option('_ff_search_submit_border_radius'));  ?>" >
            </div>
            <div>
              <label>Button up / down</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_submit_relative_top" data-field="Submit_relative_top" min="-15" max="15"  value="<?php echo esc_html(get_option('_ff_search_submit_relative_top'));  ?>" >
            </div>
            <div>
              <label>Button line height</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_submit_line_height" data-field="Submit_line_height"  min="1" max="2" step=".1"  value="<?php echo esc_html(get_option('_ff_search_submit_line_height'));  ?>" >
            </div>
            <div>
              <label>Button text color hover</label>
              <input type="color" id="ff-search-submit-text-hover" class="ff-search-box-scheme-form-control" name="_ff_search_submit_hover_color" data-field="Submit_hover_color"  value="<?php echo esc_html(get_option('_ff_search_submit_hover_color'));  ?>" >
            </div>
            <div>
              <label>Button bg color hover</label>
              <input type="color" id="ff-search-submit-bg-hover" class="ff-search-box-scheme-form-control" name="_ff_search_submit_hover_bg_color" data-field="Submit_hover_bg_color"  min="0" max="40"   value="<?php echo esc_html(get_option('_ff_search_submit_hover_bg_color'));  ?>" >
            </div>
            <div>
              <label>Message text color</label>
              <input type="color" class="ff-search-box-scheme-form-control" name="_ff_search_messages_color" data-field="Messages_color"    value="<?php echo esc_html(get_option('_ff_search_messages_color'));  ?>" >
            </div>
            <div>
              <label>Message font size</label><span class="ff-search-box-reading"></span>
              <input type="range" class="ff-search-box-scheme-form-control" name="_ff_search_messages_font_size" data-field="Messages_font_size"  min="12" max="40"   value="<?php echo esc_html(get_option('_ff_search_messages_font_size'));  ?>" >
            </div>
           
            
            <br>
            <div>
              <input type="submit" class="ff-search-box-scheme-submit" name="_ff_search-box" value="Save search-box design">
            </div>
    </form>

</div>
  <div class="ff-search-box-scheme-right">


    <div class="ff-search-admin">
        <form role="search" class="ff-search-form-admin">
          <div  class="ff-search-div-admin">
            <label >
              <input  type="search" class="ff-search-field-admin" placeholder="<?php echo esc_attr_x( 'Search FAQs', 'placeholder' ); ?>" value="<?php echo get_search_query(); ?>" name="faqs" />
              <button type="submit" class="ff-search-submit-admin" ><span class="material-symbols-outlined ff-search-submit-i-admin">search</span></button>
            </label>
          </div>
        </form>
        <div class="ff-search-msg-admin"><p>This FaQ question message area just has font color and font size for its style.</p></div>
    </div>
    


  </div>


</div>
</div>