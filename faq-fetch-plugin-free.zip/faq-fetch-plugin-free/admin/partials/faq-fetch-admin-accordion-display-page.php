<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin
 * @since      1.0.0
 *
 * @package    Faq_Fetch
 * @subpackage Faq_Fetch/admin/partials
 */
// This file should primarily consist of HTML with a little bit of PHP.

if(isset($_POST['_ff_accordion'])){


  update_option('_ff_accordion_wrapper_max_width-square', sanitize_text_field($_POST['_ff_accordion_wrapper_max_width-square']));
  update_option('_ff_accordion_margin_bottom-square', sanitize_text_field($_POST['_ff_accordion_margin_bottom-square']));
  update_option('_ff_accordion_border_bottom_color-square', sanitize_text_field($_POST['_ff_accordion_border_bottom_color-square']));
  update_option('_ff_accordion_border_bottom_width-square', sanitize_text_field($_POST['_ff_accordion_border_bottom_width-square']));
  update_option('_ff_label_color-square', sanitize_text_field($_POST['_ff_label_color-square']));
  update_option('_ff_label_padding-square', sanitize_text_field($_POST['_ff_label_padding-square']));
  $label_bg = (isset($_POST['_ff_label_background-square']) && $_POST['_ff_label_background-square'] !== 'transparent') ? sanitize_text_field($_POST['_ff_label_background-square']) : 'transparent';
  update_option('_ff_label_background-square', $label_bg);
  update_option('_ff_label_font_size-square', sanitize_text_field($_POST['_ff_label_font_size-square']));
  update_option('_ff_label_border_radius-square', sanitize_text_field($_POST['_ff_label_border_radius-square']));
  $label_hover_bg = (isset($_POST['_ff_label_background_hover-square']) && $_POST['_ff_label_background_hover-square'] !== 'transparent') ? sanitize_text_field($_POST['_ff_label_background_hover-square']) : 'transparent';
  update_option('_ff_label_background_hover-square', $label_hover_bg);
  update_option('_ff_label_border_width-square', sanitize_text_field($_POST['_ff_label_border_width-square']));
  update_option('_ff_label_border_color-square', sanitize_text_field($_POST['_ff_label_border_color-square']));
  update_option('_ff_content_color-square', sanitize_text_field($_POST['_ff_content_color-square']));
  $content_bg = (isset($_POST['_ff_content_background-square']) && $_POST['_ff_content_background-square'] !== 'transparent') ? sanitize_text_field($_POST['_ff_content_background-square']) : 'transparent';
  
  update_option('_ff_content_background-square', $content_bg);
  update_option('_ff_content_font_size-square', sanitize_text_field($_POST['_ff_content_font_size-square']));
  update_option('_ff_content_border_radius-square', sanitize_text_field($_POST['_ff_content_border_radius-square']));
  update_option('_ff_accordion_margin_top-square', sanitize_text_field($_POST['_ff_accordion_margin_top-square']));
  // update_option('_ff_category_padding-square', sanitize_text_field($_POST['_ff_category_padding-square']));
  // $category_bg = (isset($_POST['_ff_category_background-square']) && $_POST['_ff_category_background-square'] !== 'transparent') ? sanitize_text_field($_POST['_ff_category_background-square']) : 'transparent';
  // update_option('_ff_category_background-square', $category_bg);
  // update_option('_ff_category_color-square', sanitize_text_field($_POST['_ff_category_color-square']));
  // update_option('_ff_category_font_size-square', sanitize_text_field($_POST['_ff_category_font_size-square']));
  // update_option('_ff_category_border_radius-square', sanitize_text_field($_POST['_ff_category_border_radius-square']));
  // stop default styles from running
  update_option('_ff_default_styles_ran_accordion', true);
}


// Default styles for the accordion 
if(!esc_html(get_option('_ff_default_styles_ran_accordion'))){


  // accordion styles 
  update_option('_ff_accordion_wrapper_max_width-square', 780);
  update_option('_ff_accordion_margin_bottom-square', 0);
  update_option('_ff_accordion_border_bottom_color-square','#ffffff');
  update_option('_ff_accordion_border_bottom_width-square', 2);
  update_option('_ff_label_color-square', '#ffffff');
  update_option('_ff_label_padding-square', 30);
  update_option('_ff_label_background-square', '#0a365c');
  update_option('_ff_label_font_size-square', 22);
  update_option('_ff_label_border_radius-square', 0);
  update_option('_ff_label_background_hover-square', '#1a4d75');
  update_option('_ff_label_border_width-square', 0);
  update_option('_ff_label_border_color-square', '');
  update_option('_ff_content_color-square', '#d1d1d1');
  update_option('_ff_content_background-square', '#083359');
  update_option('_ff_content_font_size-square', 19);
  update_option('_ff_content_border_radius-square', 0);
  update_option('_ff_accordion_margin_top-square', 20);
  // update_option('_ff_category_padding-square', 10);
  // update_option('_ff_category_background-square', '#113f69');
  // update_option('_ff_category_color-square', '#a7b0b4');
  // update_option('_ff_category_font_size-square', 16);
  // update_option('_ff_category_border_radius-square', 0);
  // stop default styles from running
  update_option('_ff_default_styles_ran_accordion', true);


}



?>



<!-- The container for grid css setup -->
<div class="ff-accordion-scheme-container">


<div class="ff-accordion-scheme-form-wrapper ff-accordion-scheme-left">
  <h1> Accordion scheme </h1>
  <br>
   <form method="post" action="" class="ff-accordion-scheme-form ff-scheme-form" >
         
          <h4>Styles to choose</h4>
        
            <div class="ff-scheme-with-premium-blank">
              <label>Category padding</label><span class="ff-accordion-reading"></span><span class="ff-scheme-with-premium"> with premium</span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_category_padding-square" data-field="Category_padding"  min="0" max="50"   value="<?php echo esc_html(get_option('_ff_category_padding-square'));  ?>" >
            </div> 
            <div class="ff-scheme-with-premium-blank">
              <label>Category Background</label><span class="ff-scheme-with-premium"> with premium</span>
                <label class="ff-accordion-switch">
                  <input type="checkbox" id="ff-accordion-admin-category"  class="faq-fetch-accordion-checkbox">
                  <span class="ff-accordion-slider ff-accordion-round"></span>
                </label>
                <input type="color" id="ff-accordion-scheme-category-background" class="ff-accordion-scheme-form-control" data-field="Category_background"  value="<?php echo esc_html(get_option('_ff_category_background-square'));  ?>" >
                <input type="hidden" id="ff-accordion-scheme-category-background-val"  name="_ff_category_background-square" value="<?php echo esc_html(get_option('_ff_category_background-square'));  ?>" >
             
            </div>
            <div class="ff-scheme-with-premium-blank">
              <label>Category text color</label><span class="ff-scheme-with-premium"> with premium</span>
              <input type="color" class="ff-accordion-scheme-form-control" name="_ff_category_color-square" data-field="Category_text_color"  value="<?php echo esc_html(get_option('_ff_category_color-square'));  ?>" >
            </div>
            <div class="ff-scheme-with-premium-blank">
              <label>Category font size</label><span class="ff-accordion-reading"></span><span class="ff-scheme-with-premium"> with premium</span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_category_font_size-square" data-field="Category_font_size" min="10" max="40"    value="<?php echo esc_html(get_option('_ff_category_font_size-square'));  ?>" >
            </div>
            <div class="ff-scheme-with-premium-blank">
              <label>Category border radius</label><span class="ff-accordion-reading"></span><span class="ff-scheme-with-premium"> with premium</span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_category_border_radius-square" data-field="Category_border_radius" min="0" max="75"    value="<?php echo esc_html(get_option('_ff_category_border_radius-square'));  ?>" >
            </div>
            <div>
              <label>Max width</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_accordion_wrapper_max_width-square" data-field="Max_width"  min="250" max="1080"   value="<?php echo esc_html(get_option('_ff_accordion_wrapper_max_width-square'));  ?>" >
            </div>
            <div>
              <label>Accordion wrapper margin top</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_accordion_margin_top-square" data-field="Accordion_margin_top"  min="0" max="100"   value="<?php echo esc_html(get_option('_ff_accordion_margin_top-square'));  ?>" >
            </div>
            
            <div>
              <label>Accordion margin</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_accordion_margin_bottom-square" data-field="Accordion_margin_bottom"  min="0" max="100"   value="<?php echo esc_html(get_option('_ff_accordion_margin_bottom-square'));  ?>" >
            </div>
            <div>
              <label>Accordion border bottom color</label>
              <input type="color" class="ff-accordion-scheme-form-control" name="_ff_accordion_border_bottom_color-square" data-field="Accordion_border_bottom_color"  value="<?php echo esc_html(get_option('_ff_accordion_border_bottom_color-square'));  ?>" >
            </div>
            <div>
              <label>Accordion border bottom width</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_accordion_border_bottom_width-square" data-field="Accordion_border_bottom_width"  min="0" max="40"   value="<?php echo esc_html(get_option('_ff_accordion_border_bottom_width-square'));  ?>" >
            </div>
            <div>
              <label>Label text color</label>
              <input type="color" class="ff-accordion-scheme-form-control" name="_ff_label_color-square" data-field="Label_text_color"  value="<?php echo esc_html(get_option('_ff_label_color-square'));  ?>" >
            </div>
            <div>
              <label>Label padding</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_label_padding-square" data-field="Label_padding"  min="0" max="50"   value="<?php echo esc_html(get_option('_ff_label_padding-square'));  ?>" >
            </div>
            <div>
              <label>Label background</label>
              <label class="ff-accordion-switch">
                <input type="checkbox" id="ff-accordion-admin-label"  class="faq-fetch-accordion-checkbox" >
                <span class="ff-accordion-slider ff-accordion-round"></span>
              </label>
              <input type="color" id="ff-accordion-scheme-label-background" class="ff-accordion-scheme-form-control" data-field="Label_background_static"  value="<?php echo esc_html(get_option('_ff_label_background-square'));  ?>" >
              <input type="hidden" id="ff-accordion-scheme-label-background-val"  name="_ff_label_background-square" value="<?php echo esc_html(get_option('_ff_label_background-square'));  ?>" >
            </div>
            <div>
              <label>Label font size</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_label_font_size-square" data-field="Label_font_size" min="10" max="40"    value="<?php echo esc_html(get_option('_ff_label_font_size-square'));  ?>" >
            </div>
           
            <div>
              <label>Label border color</label>
              <input type="color" class="ff-accordion-scheme-form-control" name="_ff_label_border_color-square" data-field="Label_border_color"  value="<?php echo esc_html(get_option('_ff_label_border_color-square'));  ?>" >
            </div>
            <div>
              <label>Label border width</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_label_border_width-square" data-field="Label_border_width"  min="0" max="40"   value="<?php echo esc_html(get_option('_ff_label_border_width-square'));  ?>" >
            </div>
           
            <div>
              <label>Label border radius</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_label_border_radius-square" data-field="Label_border_radius" min="0" max="75"    value="<?php echo esc_html(get_option('_ff_label_border_radius-square'));  ?>" >
            </div>
            <div>
              <label>Label background hover</label>
              <label class="ff-accordion-switch">
                <input type="checkbox" id="ff-accordion-admin-label-h"  class="faq-fetch-accordion-checkbox" >
                <span class="ff-accordion-slider ff-accordion-round"></span>
              </label>
              <input type="color" id="ff-accordion-scheme-label-background-hover" class="ff-accordion-scheme-form-control" data-field="Label_background_hover"  value="<?php echo esc_html(get_option('_ff_label_background_hover-square'));  ?>" >
              <input type="hidden" id="ff-accordion-scheme-label-background-hover-val"  name="_ff_label_background_hover-square"  value="<?php echo esc_html(get_option('_ff_label_background_hover-square'));  ?>" >
            </div>
            <div>
              <label>Content color</label>
              <input type="color" class="ff-accordion-scheme-form-control" name="_ff_content_color-square" data-field="Content_color"  value="<?php echo esc_html(get_option('_ff_content_color-square'));  ?>" >
            </div>
            <div>
              <label>Content background</label>
              <label class="ff-accordion-switch">
                <input type="checkbox" id="ff-accordion-admin-content"  class="faq-fetch-accordion-checkbox" >
                <span class="ff-accordion-slider ff-accordion-round"></span>
              </label>
              <input type="color" id="ff-accordion-scheme-content-background" class="ff-accordion-scheme-form-control" name="_ff_content_background-square"  data-field="Content_background"  value="<?php echo esc_html(get_option('_ff_content_background-square'));  ?>" >
              <input type="hidden" id="ff-accordion-scheme-content-background-val"  name="_ff_content_background-square"  value="<?php echo esc_html(get_option('_ff_content_background-square'));  ?>" >
            </div>
            <div>
              <label>Content font size</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_content_font_size-square" data-field="Content_font_size"   min="10" max="40"  value="<?php echo esc_html(get_option('_ff_content_font_size-square'));  ?>" >
            </div>
            <div>
              <label>Content border radius</label><span class="ff-accordion-reading"></span>
              <input type="range" class="ff-accordion-scheme-form-control" name="_ff_content_border_radius-square" data-field="Content_border_radius" min="0" max="40"  value="<?php echo esc_html(get_option('_ff_content_border_radius-square'));  ?>" >
            </div>
           
            <br>
            <div>
              <input type="submit" class="ff-accordion-scheme-submit" name="_ff_accordion" value="Save Accordion design">
            </div>
    </form>

</div>
  <div class="ff-accordion-scheme-right">
        <section>
					<div class="ff-accordion-admin-wrapper">
            <p class="ff-accordion-admin-category">
                Category <span class="ff-scheme-with-premium"> with premium</span>
              </p>
								<div class="ff-accordion-admin">
									<input type="checkbox" name="radio-a" id="check">
									<label class="ff-accordion-admin-label" for="check">
                    <p class="ff-accordion-admin-label-content">
											<span>
												The Faq question
											</span>
										  <br>
										  <br>
											<span>
                         Lorem ipsum dolor sit amet...<span class="ff-scheme-with-premium"> with premium</span>
											</span>
										</p>
                  </label>
									<div class="ff-accordion-admin-content">
										<p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                     Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                     Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                     Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
                    </p>
									</div>
								</div> 
                <div id="ff-accordion-2" class="ff-accordion-admin">
									<input type="checkbox" name="radio-a" id="check2">
									<label class="ff-accordion-admin-label" for="check2">
                    <p class="ff-accordion-admin-label-content">
											<span>
												The Faq question 2
											</span>
										  <br>
                      <br>
											<span>
                         Lorem ipsum dolor sit amet...<span class="ff-scheme-with-premium"> with premium</span>
											</span>
										</p>
                  </label>
									<div class="ff-accordion-admin-content">
										<p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                     Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                     Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                     Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
                    </p>
									</div>
								</div> 
           
					</div>	
          </section>
  </div>


</div>