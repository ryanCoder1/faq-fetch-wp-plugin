<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin
 * @since      1.0.0
 *
 * @package    Faq_Fetch
 * @subpackage Faq_Fetch/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Faq_Fetch
 * @subpackage Faq_Fetch/admin
 * @author     Ryan lackey <ryanlackey1976@gmail.com>
 */
class Faq_Fetch_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $faq_fetch    The ID of this plugin.
	 */
	private $faq_fetch;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $faq_fetch       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $faq_fetch, $version ) {

		$this->faq_fetch = $faq_fetch;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Faq_Fetch_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Faq_Fetch_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if( is_admin() ) {
			wp_enqueue_style( $this->faq_fetch, plugin_dir_url( __FILE__ ) . 'css/faq-fetch-admin-search.css', array(), $this->version, 'all' );
			wp_enqueue_style( $this->faq_fetch.'-accordion-admin-scheme', plugin_dir_url( __FILE__ ) . 'css/faq-fetch-admin-accordion-scheme.css', array(), $this->version, 'all' );
			wp_enqueue_style( $this->faq_fetch.'-search-box-admin-scheme', plugin_dir_url( __FILE__ ) . 'css/faq-fetch-admin-search-box-scheme.css', array(), $this->version, 'all' );
		}
		// wp_dequeue_style( $this->faq_fetch.'_square' );
		 wp_enqueue_style( 'font-search-google', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200' );

		
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Faq_Fetch_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Faq_Fetch_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		$ajaxurl_arr = array('ajax_url' => admin_url('admin-ajax.php'));
		if( is_admin() ) {
			
			wp_enqueue_script( $this->faq_fetch, plugin_dir_url( __FILE__ ) . 'js/faq-fetch-admin.js', array( 'jquery' ), $this->version, false );
			wp_enqueue_script( $this->faq_fetch.'admin-search-box-scheme', plugin_dir_url( __FILE__ ) . 'js/faq-fetch-admin-search.js', array( 'jquery' ), $this->version, false );
		}
		$ajaxurl_arr_admin = array('ajax_url' => admin_url('admin-ajax.php'),
							 'nonce' => wp_create_nonce('faq-fetch-ajax-nonce'));
	    wp_enqueue_script('wp-deactivation-message', plugins_url('js/message-deactivate.js', __FILE__), array( 'jquery' ), $this->version, false );
		wp_localize_script($this->faq_fetch, 'ajaxurl_arr_admin', $ajaxurl_arr_admin);	
	}


	/**
	 * Add admin menu
	 *
	 * @since    1.0.0
	 */
	function faq_fetch_admin_menu(){
		add_menu_page( 'Faq Fetch Search', 'Faq Fetch', 'manage_options', 'edit.php?post_type=faqs', null  , $icon_url = 'dashicons-search', $position = 5 );
		add_submenu_page( 'edit.php?post_type=faqs', 'Add Faqs', 'Add Faqs','manage_options','edit.php?post_type=faqs', null );
		$taxonomies = get_taxonomies( array( '_builtin' => false ), 'objects' );
		foreach ( $taxonomies as $taxonomy ) {
			$post_type = $taxonomy->object_type[0];
			$page_title = $taxonomy->labels->menu_name;
			$menu_title = $taxonomy->labels->menu_name.'<span class="ff-scheme-with-premium"> w/ Premium</span>';
			$capability = 'manage_options';
			$menu_slug = 'edit-tags.php?taxonomy=' . $taxonomy->name;
			add_submenu_page(
				'edit.php?post_type='.$post_type,
				$page_title,
				$menu_title,
				$capability,
				$menu_slug
			);
		}
		add_submenu_page( 'edit.php?post_type=faqs', 'Faq Search', 'Faq Search','manage_options' ,'faq_search', array($this, 'faq_fetch_admin_search_shortcode_page') );
		add_submenu_page( 'edit.php?post_type=faqs', 'Accordion Template', 'Accordion Template','manage_options' ,'accordion_template', array($this, 'faq_fetch_admin_accordion_page') );
		add_submenu_page( 'edit.php?post_type=faqs', 'Search Box Template', 'Search Box Template','manage_options' ,'search_template', array($this, 'faq_fetch_admin_search_box_page') );
	 
	
	
	}

	 /** 
	 * 
	 * When in the faq categories page stop the parent menu post from getting the focus 
	 * @since    1.0.0
     */
	function ff_change_post_menu_parent_file( $parent_file ) {
		global $submenu_file, $post_type;
		
		if ( $post_type == 'post' && $submenu_file == 'edit-tags.php?taxonomy=faq-categories' ) {
			$parent_file = 'edit.php?post_type=faqs';
		}
	
		return $parent_file;
	}

	
	 /** 
	 * 
	 * Notice message for to enter designated email address
	 * @since    1.0.0
     */
	function ff_admin_notice_email_null() {
		?>
		<div class="notice error is-dismissible" >
			<p><?php _e( 'Please remember to enter a designated email address to receive new FaQ questions!', 'ff' ); ?></p>
		</div>
		<?php
	}
	 /*
	 * 
	 * Notice message for email is set. 
	 * @since    1.0.0
     */
	function ff_admin_notice_email_new() {
		?>
		<div class="notice update is-dismissible" >
			<p><?php _e( 'The email is set. You will receive new FaQ questions at this email destination.', 'ff' ); ?></p>
		</div>
		<?php
	}
	 /*
	 * With both search box and accordion, set default styles ran to true if loaded on page once
	 * Gives a default style when first seen
	 * @since    1.0.0
     */
	 function faq_fetch_default_styles_ran(){
		
		if(get_option('_ff_default_styles_ran_search_box')){
			sanitize_text_field(update_option('_ff_default_styles_ran_search_box', true));
		}else{
			sanitize_text_field(update_option('_ff_default_styles_ran_search_box', false));
		}

		if(get_option('_ff_default_styles_ran_accordion')){
			sanitize_text_field(update_option('_ff_default_styles_ran_accordion', true));
		}else{
			sanitize_text_field(update_option('_ff_default_styles_ran_accordion', false));
		}


	 }
		
		/** 
		 *  Make Custom Column Sortable
		* 	@since    1.0.0
		*/
		function faq_fetch_make_custom_column_sortable( $columns ) {
			$columns['count'] = 'Count';
			$columns['taxonomy'] = 'Faq Categories';

			return $columns;
		}

		  /**
		   * Change faqs columns order
		   *
		   * @since    1.0.0
		   */
		function change_faqs_columns( $columns ) {

			$columns = array(
			'cb' => $columns['cb'],
			'title' => __( 'FaQ' ),
			'count' => __( 'Times searched' ),
			'taxonomy' => __('Faq Categories'),
			'content' => __( 'Answer' ),
			'date' => __( 'Date' ),
			);

		return $columns;

		}


		/**
		 * Populate faqs column
		 * 
		 *
		 * @since    1.0.0
		 */
		function populate_faqs_column( $column, $post_id ) {
			// use switch to populate columns

			switch($column){
				case 'content' :
						esc_html(the_content( $post_id ));
				break;
				case 'count' :
					// only way to show get_post_meta.
					$count = get_post_meta( $post_id, '_ff_count', true );
				  	 echo esc_html($count);
				break;
				case 'taxonomy' : 
					// Get all taxonomies associated with the current post type
					$taxonomies = get_object_taxonomies( 'faqs' );
					
					// Loop through all taxonomies
					foreach ( $taxonomies as $taxonomy ) {
					// Get all terms belonging to this taxonomy
					$terms = the_terms( $post_id, $taxonomy );
					if($terms){
						 esc_html($terms[0]->name);
					}
				}
						
				break;	
				default :
				break;
			}
  
	 }
	


		/**
			 * Register faqs custom post type
			 *
			 * @since    1.0.0
			 */
			function register_faqs_cpt(){

				$labels = array(
								'name'               =>   _x('Faqs', 'post type general name'),
								'singular_name'=>   _x('Faq', 'post type singular name'),
								'menu_name'          =>   _x('Faqs', 'admin menu'),
								'name_admin_bar'     =>   _x('All Faqs', 'add new on admin bar'),
								'add_new'             =>   _x('Add New', ''),
								'add_new_item'        =>   __('Add New Faq'),
								'edit_item'           =>   __('Edit Faq'),
								'new_item'            =>   __('New Faq'),
								'all_items'           =>   __('All Faq'),
								'view_item'           =>   __('View Faq'),
								'search_items'        =>   __('Search Faqs'),
								'not_found'           =>   __('No Faqs found'),
								'not_found_in_trash' =>   __('No Faqs found in Trash'),
								'parent_item_colon'  =>   __('Parent Faqs:'),
								'featured_image'        => __( 'Featured Image', 'text_domain' ),
								'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
								'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
								'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
								'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
								'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),

				);

				$args = array(
						'hierarchical'       =>  false,
						'labels'             =>  $labels,
						'public'             =>  true,
						'publicly_queryable' =>  true,
						'description'        => __('Description.'),
						'show_ui'            =>  true,
						'show_in_menu'       =>  'edit.php?post_type=faqs',
						'show_in_nav_menus'  =>  true,
						'query_var'          =>  true,
						'rewrite'            =>  true,
						'query_var'          =>  true,
						'rewrite'            =>  array('slug' => 'faqs'),
						'capability_type'    =>  'post',
						'has_archive'        =>  true,
						'menu_position'      =>   22,
						"show_in_rest"       =>  true,
						'supports'           =>  array( 'title', 'editor', 'thumbnail'),
						'taxonomies'  => array( 'faq-categories' ),

				);

			register_post_type('faqs', $args);

		}



		/**
			 * Register faqs taxonomy
			 *
			 * @since    1.0.0
			 */
		function create_faq_categories_taxonomy() {
			$labels = array(
				'name'                       => 'Faq categories',
				'singular_name'              => 'Faq category',
				'menu_name'                  => 'Faq categories',
				'all_items'                  => 'All Faq categories',
				'parent_item'                => 'Parent Faq category',
				'parent_item_colon'          => 'Parent Faq category:',
				'new_item_name'              => 'New Faq category Name',
				'add_new_item'               => 'Add New Faq category',
				'edit_item'                  => 'Edit Faq category',
				'update_item'                => 'Update Faq category',
				'view_item'                  => 'View Faq category',
				'separate_items_with_commas' => 'Separate Faq categories with commas',
				'add_or_remove_items'        => 'Add or remove Faq categories',
				'choose_from_most_used'      => 'Choose from the most used Faq categories',
				'popular_items'              => 'Popular Faq categories',
				'search_items'               => 'Search Faq categories',
				'not_found'                  => 'Not Found',
				'no_terms'                   => 'No Faq categories',
				'items_list'                 => 'Faq categories list',
				'items_list_navigation'      => 'Faq categories list navigation',
			);
			$args = array(
				'labels'                     => $labels,
				'hierarchical'               => true,
				'public'                     => true,
				'show_ui'                    => true,
				'show_admin_column'          => true,
				'show_in_nav_menus'          => true,
				'show_tagcloud'              => true,
				'rewrite'                    => array( 'slug' => 'faq-categories' ),
			);

			register_taxonomy( 'faq-categories', array( 'faqs' ), $args ); 

		}
		
		/**
		 * Add taxonomy meta box to custom post type in post.php
		* 
		*
		* @since    1.0.0
		*/
		function ff_add_faq_categories_taxonomy_meta_box() {
			add_meta_box( 
				'faq_categories_taxonomy_meta_box',
				__( 'Faq categories', 'textdomain' ),
				array($this,'ff_taxonomy_meta_box_callback'),
				'faqs',
				'side',
				'default' 
			);
		}
		 
		/** 
		* Callback function to display taxonomy meta box
		*
		* @since    1.0.0
		*/
		function ff_taxonomy_meta_box_callback( $post ) {
			wp_nonce_field( basename( __FILE__ ), 'ff_faq_categories_taxonomy_meta_box_nonce' );

			$terms = get_terms( array(
				'taxonomy' => 'faq-categories',
				'hide_empty' => false,
			) );

			$post_terms = wp_get_object_terms( $post->ID, 'faq-categories', array( 'fields' => 'ids' ) );

			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					?>
					<div>
						<label>
							<input type="checkbox" name="faq_categories[]" value="<?php echo $term->term_id; ?>" <?php if ( in_array( $term->term_id, $post_terms ) ) echo 'checked'; ?>><?php echo $term->name; ?>
						</label>
					</div>
					<?php
				}
			}
		}
		
		/** 
		* Save custom taxonomy meta box data
		*
		* @since    1.0.0
		*/
		function ff_save_faq_categories_taxonomy_meta_box_data( $post_id ) {
			if ( ! isset( $_POST['ff_faq_categories_taxonomy_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['ff_faq_categories_taxonomy_meta_box_nonce'], basename( __FILE__ ) ) ) {
				return;
			}

			$taxonomy = 'faq-categories';
			if ( isset( $_POST['faq_categories'] ) && is_array( $_POST['faq_categories'] ) ) {
				$terms = array_map( 'intval', $_POST['faq_categories'] );
			} else {
				$terms = array();
			}

			wp_set_object_terms( $post_id, $terms, $taxonomy, false );
		}


		/**
		 * Add categories to custom post type 'faqs'
		 *
		 * @since    1.0.0
		 */
		function faq_fetch_add_categories() {
			register_taxonomy_for_object_type(  'category', 'faq-categories' );
		}
		
		/**
		 * Add count of 1 to faq posts if Times Searched is 0 / null 
		 *
		 * @since    1.0.0
		 */
		function faq_fetch_add_count_to_posts(){

			global $wpdb;

			// Get the custom post type
			$post_type = 'faqs';
			$trash = 'trash';

			$faq_ids = array();

			// Retrieve all the IDs of posts from the post type 'faqs'
				$faqs = new WP_Query( array(
					'post_type' => 'faqs',
					'posts_per_page' => -1, // Set to -1 to retrieve all posts
					'fields' => 'ids', // Only retrieve IDs, not full post objects
				) );

				// Store the IDs in an array
				$faq_ids = $faqs->posts;

				// Output the IDs
				foreach ( $faq_ids as $id ) {


					$old =  get_post_meta( $id, '_ff_count', true );
					if($old < 1){
						update_post_meta( $id, '_ff_count', 1 );
					}
					
				}
		
		}


		/**
		 * Registering custom field Video for the faqs post type function
		 *
		 * @since    1.0.0
		 */
		
		function ff_add_custom_field_faqs() {
			// Adding meta box to custom post type 'faqs'
			add_meta_box(
				'ff_video_url_field',
				__( 'FAQ Video: ONLY ACCEPT THE YOUTUBE EMBEDDED URL e.g. Full <iframe></iframe> embed', 'ff' ),
				array($this,'ff_video_url_field_callback'),
				'faqs',
				'normal',
				'default',
				
			);
		}



		/**
		 * Callback function to display custom field in meta box
		 *
		 * @since    1.0.0
		 */
		
		function ff_video_url_field_callback( $post ) {
			// Adding nonce for security
			wp_nonce_field( 'ff_save_video_url_field', 'ff_video_url_field_nonce' );

			// Retrieving current value of the video URL from database
			$video_url = get_post_meta( $post->ID, 'ff_video_url_field_meta_key', true );

			// If the custom field is not empty
			if ( ! empty( $video_url ) ) {
				echo '<label for="ff_video_url_field">' . __( 'Video URL:', 'ff' ) . '</label>';
			}

			// Displaying input field for custom field
			echo '<textarea id="ff_video_url_field" name="ff_video_url_field" class="widefat" style="width:100%;">' . esc_textarea( $video_url ) . '</textarea>';
			
		}




		/**
		 * Saving custom field value video
		 *
		 * @since    1.0.0
		 */
		function ff_save_custom_field_value( $post_id ) {
			// Checking if nonce is set
			if ( ! isset( $_POST['ff_video_url_field_nonce'] ) ) {
				return;
			}
			// Verifying nonce for security
			if ( ! wp_verify_nonce( $_POST['ff_video_url_field_nonce'], 'ff_save_video_url_field' ) ) {
				return;
			}
			// Checking if the user has permission to edit the post
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}
			// Saving/updating the post meta for custom field
			$video_url = ( isset( $_POST['ff_video_url_field'] ) ?  wp_kses_post( $_POST['ff_video_url_field'] ) : '' );
			update_post_meta( $post_id, 'ff_video_url_field_meta_key', $video_url );
		}


		/**
		 * Add CSS STYLES IN HEADER FOR PUBLIC ACCORDION
		 * Retrieve styles from database 
		 * 
		 * @since    1.0.0
		 */
		function adjust_css_styles_ff(){
		
		
			$data = array();

			$data['_ff_accordion_wrapper_max_width-square'] = sanitize_text_field(get_option('_ff_accordion_wrapper_max_width-square'));
			$data['_ff_accordion_margin_bottom-square'] = sanitize_text_field(get_option('_ff_accordion_margin_bottom-square'));
			$data['_ff_accordion_border_bottom_color-square'] = sanitize_text_field(get_option('_ff_accordion_border_bottom_color-square'));
			$data['_ff_accordion_border_bottom_width-square'] = sanitize_text_field(get_option('_ff_accordion_border_bottom_width-square'));
			$data['_ff_label_color-square'] = sanitize_text_field(get_option('_ff_label_color-square'));
			$data['_ff_label_padding-square'] = sanitize_text_field(get_option('_ff_label_padding-square'));
			$data['_ff_label_background-square'] = sanitize_text_field(get_option('_ff_label_background-square'));
			$data['_ff_label_font_size-square'] = sanitize_text_field(get_option('_ff_label_font_size-square'));
			$data['_ff_label_border_color-square'] = sanitize_text_field(get_option('_ff_label_border_color-square'));
			$data['_ff_label_border_width-square'] = sanitize_text_field(get_option('_ff_label_border_width-square'));
			$data['_ff_label_border_radius-square'] = sanitize_text_field(get_option('_ff_label_border_radius-square'));
			$data['_ff_label_background_hover-square'] = sanitize_text_field(get_option('_ff_label_background_hover-square'));
			$data['_ff_content_color-square'] = sanitize_text_field(get_option('_ff_content_color-square'));
			$data['_ff_content_font_size-square'] = sanitize_text_field(get_option('_ff_content_font_size-square'));
			$data['_ff_content_background-square'] = sanitize_text_field(get_option('_ff_content_background-square'));
			$data['_ff_content_border_radius-square'] = sanitize_text_field(get_option('_ff_content_border_radius-square'));
			
			
			$stylesArg = '';
		
		
				$dataKeys = array_keys($data);
				$dataValues = array_values($data);
			
			  
		$stylesArg = '
				 .accordion-admin-wrapper {
						max-width: "'. ($dataKeys[0] === '_ff_accordion_wrapper_max_width-square' ?  $dataValues[0].'px'  : '' ).'";
					}
				 .accordion-admin {
						margin-bottom: "'. ($dataKeys[1] === '_ff_accordion_margin_bottom-square' ?  $dataValues[1].'px'  : '' ).'";
						border-bottom-color: "'. ($dataKeys[2] === '_ff_accordion_border_bottom_color-square' ?  $dataValues[2]  : '' ).'";
						border-bottom-width: "'. ($dataKeys[3] === '_ff_accordion_border_bottom_width-square' ?  $dataValues[3].'px'  : '' ).'";
					}
					
					.accordion-admin-label {
						color: "'. ($dataKeys[4] === '_ff_label_color-square' ?  $dataValues[4]  : '' ).'";
						padding: "'. ($dataKeys[5] === '_ff_label_padding-square' ?  $dataValues[5].'px'  : '' ).'";
						background-color: "'. ($dataKeys[6] === '_ff_label_background-square' ?  $dataValues[6]  : '' ).'";
						font-size: "'. ($dataKeys[7] === '_ff_label_font_size-square' ?  $dataValues[7].'px'  : '' ).'";
						border-color: "'. ($dataKeys[8] === '_ff_label_border_color-square' ?  $dataValues[8]  : '' ).'";
						border-width: "'. ($dataKeys[9] === '_ff_label_border_width-square' ?  $dataValues[9].'px'  : '' ).'";
						border-radius: "'. ($dataKeys[10] === '_ff_label_border_radius-square' ?  $dataValues[10].'px'  : '' ).'";
					}
					
					.accordion-admin-label:hover {
						background-color: "'. ($dataKeys[11] === '_ff_label_background_hover-square' ?  $dataValues[11]  : '' ).'";
					}
				
					.accordion-admin-content {
						color: "'. ($dataKeys[12] === '_ff_content_color-square' ?  $dataValues[12]  : '' ).'";
						font-size: "'. ($dataKeys[13] === '_ff_content_font_size-square' ?  $dataValues[13].'px'  : '' ).'";
						background-color: "'. ($dataKeys[14] === '_ff_content_background-square' ?  $dataValues[14]  : '' ).'";
						border-radius: "'.  ($dataKeys[15] === '_ff_content_border_radius-square' ?  $dataValues[15].'px' : '') .'";
					}
				 ';
				
				wp_enqueue_style( $this->faq_fetch.'-accordion-admin-css', get_stylesheet_uri(), array(), '1.0' );
				wp_add_inline_style($this->faq_fetch.'-accordion-admin-css', $stylesArg);

		}						
	

		/**
		* Page to create shortcodes for search box / accordion results
		* 
		*
		* @since    1.0.0
		*/
		function faq_fetch_admin_search_shortcode_page(){
			require_once plugin_dir_path( __FILE__ ).'partials/faq-fetch-admin-search-shortcode-page-display.php';
		}



		/**
		* Page for accordion scheme styles
		*
		* @since    1.0.0
		*/
		function faq_fetch_admin_accordion_page(){
			require_once plugin_dir_path( __FILE__ ).'partials/faq-fetch-admin-accordion-display-page.php';
		}


		
		/**
		* Page for search box scheme styles
		*
		* @since    1.0.0
		*/
		function faq_fetch_admin_search_box_page(){
			require_once plugin_dir_path( __FILE__ ).'partials/faq-fetch-admin-search-box-display-page.php';
		}
/**
		* ajax call on Plugin Deactivate for uninstall procedures
		*
		* @since    1.0.0
		*/
		function uninstall_check_ff_false(  ) {
			if (!isset($_POST['data']['nonce']) || !wp_verify_nonce($_POST['data']['nonce'], 'faq-fetch-ajax-nonce')) {
				wp_die(-1);
			}
			update_option('_ff_save_database', $_POST['data']['save_ff_database']);

			// create array and send data back when search is duplicate
			$data = array(
				'success' => 'true'
			);
			wp_send_json($data);
			
		}

/**
		* ajax call on Plugin Deactivate for uninstall procedures
		*
		* @since    1.0.0
		*/
		function uninstall_check_ff_true(  ) {
			if (!isset($_POST['data']['nonce']) || !wp_verify_nonce($_POST['data']['nonce'], 'faq-fetch-ajax-nonce')) {
				wp_die(-1);
			}
			update_option('_ff_save_database', $_POST['data']['save_ff_database']);

			// create array and send data back when search is duplicate
			$data = array(
				'success' => 'true'
			);
			wp_send_json($data);
			
		}




}
