(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	  $( window ).load(function() {
	 
	  });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	  jQuery(document).ready(function($) {
	 
		$('body').on('click', 'input.faq-fetch-add-search-input', function(e){
			
			var textBox = document.getElementById("faq-fetch-add-search-input");
			textBox.select();
			document.execCommand("copy");
					$('.faq-fetch-add-search-copy').addClass('copied');

		});


		var bg_hover = '';	
		var bg = '';
		
		
		
			$('.ff-accordion-scheme-form-control').each(
					function(index, item) {
						// get data-field attr for input itemStyle to match in switch case with testimonial list element
						let dataField = $(item).data('field');
						let itemStyle = $(item).val();

					   switch(dataField){
						case 'Max_width' :
							$('.ff-accordion-admin-wrapper').css({'max-width': `${itemStyle}px`});
							$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
							break;
					 case 'Accordion_margin_top' :
							$('.ff-accordion-admin-wrapper').css({'margin-top': `${itemStyle}px`});
							$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
							break;
						
					 case 'Accordion_margin_bottom' :
							 $('.ff-accordion-admin').css({'margin': `${itemStyle}px 0px`});
							 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					 case 'Accordion_border_bottom_color' :
							 $('.ff-accordion-admin').css({'border-bottom-color': itemStyle});
						 break;
					 case 'Accordion_border_bottom_width' :
							 $('.ff-accordion-admin').css({'border-bottom-width': `${itemStyle}px`});
							 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					case 'Label_text_color' :
							$('.ff-accordion-admin-label').css({'color': itemStyle});
						break;
					case 'Label_padding' :
							$('.ff-accordion-admin-label').css({'padding': `${itemStyle}px 15px`});
							$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					 case 'Label_background_static' :
							checkbox_able('#ff-accordion-scheme-label-background-val', '#ff-accordion-scheme-label-background');
							if($('#ff-accordion-scheme-label-background-val').val() === 'transparent'){
								$('#ff-accordion-scheme-label-background').css({'background-color': 'transparent'});
								$('#ff-accordion-admin-label').css({'background-color': 'transparent'});
								
								$('#ff-accordion-scheme-label-background-val').css({'background-color': 'transparent'});
							}else{
								$('#ff-accordion-scheme-label-background').val(itemStyle);
								$('#ff-accordion-scheme-label-background-val').val(itemStyle);
								$('.ff-accordion-admin-label').css({'background-color': itemStyle});
							}
							
						 break;

					 case 'Label_background_hover' :
							checkbox_able('#ff-accordion-scheme-label-background-hover-val', '#ff-accordion-scheme-label-background-hover');
							if($('#ff-accordion-scheme-label-background-hover-val').val() === 'transparent'){
								$('#ff-accordion-scheme-label-background-hover').css({'background-color': 'transparent'});
							
								
								$('#ff-accordion-scheme-label-background-hover-val').css({'background-color': 'transparent'});
							}
							else{
								$('#ff-accordion-scheme-label-background-hover').val(itemStyle);
								$('#ff-accordion-scheme-label-background-hover-val').val(itemStyle);
							
							}
						 break;
					 case 'Label_font_size' :
						$('.ff-accordion-admin-label-content > span:first-child, .ff-accordion-admin-label').css({'font-size': `${itemStyle}px`});
						
							 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					 case 'Label_border_radius' :
							 $('.ff-accordion-admin-label').css({'border-radius': `${itemStyle}px`});
							 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					
					 case 'Label_border_width' :
							 $('.ff-accordion-admin-label').css({'border-width': `${itemStyle}px`});
							 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
						 case 'Label_border_color' :
							 $('.ff-accordion-admin-label').css({'border-color': itemStyle});
						 break;
					 case 'Content_color' :
							 $('.ff-accordion-admin-content').css({'color': itemStyle});
						 break;
	
					 case 'Content_background' :

							checkbox_able('#ff-accordion-scheme-content-background-val', '#ff-accordion-scheme-content-background');
							if($('#ff-accordion-scheme-content-background-val').val() === 'transparent'){
								
								$('#ff-accordion-admin-content').css({'background-color': 'transparent'});
								$('#ff-accordion-scheme-content-background').css({'background-color': 'transparent'});
							}else{
								$('#ff-accordion-scheme-content-background').val(itemStyle);
								$('#ff-accordion-scheme-content-background-val').val(itemStyle);
								$('.ff-accordion-admin-content').css({'background-color': itemStyle});
							}
								
						 break;
					 case 'Content_font_size' :
								 $('.ff-accordion-admin-content > p').css({'font-size': `${itemStyle}px`});
								 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					 case 'Content_border_radius' :
								 $('.ff-accordion-admin-content').css({'border-radius': `${itemStyle}px`});
								 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					 case 'Category_padding' :
							$('.ff-accordion-admin-category').css({'padding': `${itemStyle}px 0px ${itemStyle}px 15px`});
							$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						 break;
					
					case 'Category_background' :
						checkbox_able('#ff-accordion-scheme-category-background-val', '#ff-accordion-scheme-category-background');
						if($('#ff-accordion-scheme-category-background-val').val() === 'transparent'){
							
							$('#ff-accordion-admin-category').css({'background-color': 'transparent'});
							$('#ff-accordion-scheme-category-background').css({'background-color': 'transparent'});
						}else{
							
							$('#ff-accordion-scheme-category-background').val(itemStyle);
							$('#ff-accordion-scheme-category-background-val').val(itemStyle);
							$('.ff-accordion-admin-category').css({'background-color': itemStyle});
						}
							break;
					 case 'Category_text_color' :
							$('.ff-accordion-admin-category').css({'color': itemStyle});
						break;
					 case 'Category_font_size' :
							$('.ff-accordion-admin-category').css({'font-size': `${itemStyle}px`});
							$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						break;
						case 'Category_border_radius' :
							$('.ff-accordion-admin-category').css({'border-radius': `${itemStyle}px`});
							$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						break;
				   
					 default :
						 break;
					   
					   }

					   // get the values on page load for further use in hover events 
						bg_hover = $('#ff-accordion-scheme-label-background-hover').val();		
						bg = $('#ff-accordion-scheme-label-background').val();
					
					 });
					
				
					
	// input itemStyle change and adjust element's style
	$('.ff-accordion-scheme-form-control').on('input',
		function() {
				
				// get data-field attr for input itemStyle to match in switch case with testimonial list element
				let dataField = $(this).data('field');
				let itemStyle = $(this).val();
				switch(dataField){
				 case 'Max_width' :
						$('.ff-accordion-admin-wrapper').css({'max-width': `${itemStyle}px`});
						$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						break;
				 case 'Accordion_margin_top' :
						$('.ff-accordion-admin-wrapper').css({'margin-top': `${itemStyle}px`});
						$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
						break;
					
				 case 'Accordion_margin_bottom' :
						 $('.ff-accordion-admin').css({'margin': `${itemStyle}px 0px`});
						 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
				 case 'Accordion_border_bottom_color' :
						 $('.ff-accordion-admin').css({'border-bottom-color': itemStyle});
					 break;
				 case 'Accordion_border_bottom_width' :
						 $('.ff-accordion-admin').css({'border-bottom-width': `${itemStyle}px`});
						 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
				 case 'Label_text_color' :
						$('.ff-accordion-admin-label').css({'color': itemStyle});
					break;
				 case 'Label_padding' :
						$('.ff-accordion-admin-label').css({'padding': `${itemStyle}px 15px`});
						$(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
			     case 'Label_background_static' :
						
						if($('#ff-accordion-scheme-label-background').is(':disabled')){
							$('#ff-accordion-scheme-label-background').css({'background-color': 'transparent'});
							$('.ff-accordion-admin-label').css({'background-color': 'transparent'});
							
							$('#ff-accordion-scheme-label-background-val').css({'background-color': 'transparent'});
						}else{
							$('#ff-accordion-scheme-label-background').val(itemStyle);
							$('#ff-accordion-scheme-label-background-val').val(itemStyle);
							$('.ff-accordion-admin-label').css({'background-color': itemStyle});
						}
						
					 break;

				 case 'Label_background_hover' :
				
				 		if($('#ff-accordion-scheme-label-background-hover').is(':disabled')){
							$('#ff-accordion-scheme-label-background-hover').css({'background-color': 'transparent'});
							$('#ff-accordion-scheme-label-background-hover-val').css({'background-color': 'transparent'});
						}
						else{
							$('#ff-accordion-scheme-label-background-hover').val(itemStyle);
							$('#ff-accordion-scheme-label-background-hover-val').val(itemStyle);
						
						}
					 break;
				 case 'Label_font_size' :
					$('.ff-accordion-admin-label-content > span:first-child, .ff-accordion-admin-label').css({'font-size': `${itemStyle}px`});
						 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
				 case 'Label_border_radius' :
						 $('.ff-accordion-admin-label').css({'border-radius': `${itemStyle}px`});
						 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
				
				 case 'Label_border_width' :
						 $('.ff-accordion-admin-label').css({'border-width': `${itemStyle}px`});
						 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
					 case 'Label_border_color' :
						 $('.ff-accordion-admin-label').css({'border-color': itemStyle});
					 break;
				 case 'Content_color' :
						 $('.ff-accordion-admin-content').css({'color': itemStyle});
					 break;

				 case 'Content_background' :
						 $('.ff-accordion-admin-content').css({'background-color': itemStyle});
						 $('#ff-accordion-scheme-content-background-val').val(itemStyle);
						 $('#ff-accordion-scheme-content-background').val(itemStyle);
					 break;
				 case 'Content_font_size' :
							 $('.ff-accordion-admin-content > p').css({'font-size': `${itemStyle}px`});
							 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
				 case 'Content_border_radius' :
							 $('.ff-accordion-admin-content').css({'border-radius': `${itemStyle}px`});
							 $(this).parent().children('.ff-accordion-reading').text(itemStyle + 'px');
					 break;
				 default :
					 break;
				   }
				   // update these variables on page load function to be used later
					bg_hover = $('#ff-accordion-scheme-label-background-hover').val();		
					bg = $('#ff-accordion-scheme-label-background').val();

				});
				 

				// on page load if label background hover checked then unbind hover events
				// else : run the hover events with bg_hover / bg variables 
				if($('#ff-accordion-admin-label-h').is(':checked')) {
					
					  $('.ff-accordion-admin-label').unbind('mouseenter mouseleave');
					  
				  }else{
					
						  $('.ff-accordion-admin-label').mouseenter(function(){
							  
								  $(this).css({'background-color': bg_hover });
			  
							  });
							  $('.ff-accordion-admin-label').mouseleave(function(){
							  
								  $(this).css({'background-color': bg});
					  
						  });
					  }




					  // on page load if accordion label is checked the add check to label background hover and unbind hover effects
					  if($('#ff-accordion-admin-label').is(':checked')) {
				
						$('.ff-accordion-admin-label').unbind('mouseenter mouseleave');
						$('#ff-accordion-admin-label-h').prop('checked', true);
						
					}



					// on change if accordion label is checked the add check to label background hover and unbind hover affects
				 $('#ff-accordion-admin-label').change(function() {
					if(this.checked) {
				
						$('.ff-accordion-admin-label').unbind('mouseenter mouseleave');
						$('#ff-accordion-admin-label-h').prop('checked', true);
						
					}
				 });



				 // on change label background hover is checked unbind hover affects.
				$('#ff-accordion-admin-label-h').change(function() {
					if(this.checked) {
				
						$('.ff-accordion-admin-label').unbind('mouseenter mouseleave');
						
					}else{
						// if label is checked unbind hover events on accordion label element and check label background hover
						if($('#ff-accordion-admin-label').is(':checked')) {
					
							$('.ff-accordion-admin-label').unbind('mouseenter mouseleave');
							$(this).prop('checked', true);
							
						}else{
							// else if accordion admin label checkbox not checked run hover events
							$('.ff-accordion-admin-label').mouseenter(function(){
								
									$(this).css({'background-color': bg_hover });
				
								});
								$('.ff-accordion-admin-label').mouseleave(function(){
								
									$(this).css({'background-color': bg});
						
							});
						}
					}
				});
			

				// on submit check if any checkbox is checked and if so add transparent to input values
				$('.ff-accordion-scheme-form').submit(function(e){
					$('.faq-fetch-accordion-checkbox').each((index, item) => {
						if ($(item).is(':checked')) {	
							$(item).parent().siblings('input').val('transparent');
						}
					});
					return;

				}); 




				//when checkbox is checked, disable color input field
				$('.faq-fetch-accordion-checkbox').change( function(){
					var bg_input = $(this).parent().siblings('input');
				
					if($(this).is(':checked')){
						
						bg_input.val('transparent');
						bg_input.siblings('input[type=color]').prop('disabled', 'disabled');
					}else{
						bg_input.siblings('input[type=color]').prop('disabled', false);
						$(this).prop('checked', false);
					}
				
				});

				$('.faq-fetch-accordion-checkbox').change( function(){
					var id =$(this).prop('id');
					var id_h = id.slice(0, -2);
					 var bgh = $('#ff-accordion-scheme-label-background').val();
					if (id === 'ff-accordion-admin-label-h'){
						return;
					}
					else if($(this).is(':checked')){
						$('.' + id).css({'background-color': 'transparent'});
					}
				});



				// on page load use this function for checking / disabling the background inputs if transparent
				function checkbox_able(color_input_val, color_input){
					var checkbox = $(color_input_val).parent().children('label:nth-child(2)').find('input.faq-fetch-accordion-checkbox');
					var input_color = $(color_input_val).siblings('input');
					var color_inputs = $(color_input);
					
					if($(color_input_val).val() === 'transparent'){
	
						checkbox.prop('checked', true);
						input_color.prop('disabled', 'disabled');
						color_inputs.prop('disabled', 'disabled');
					}else{
						
						checkbox.prop('checked', false);
						input_color.prop('disabled', false);
						color_inputs.prop('disabled', false);
					}
				}
				
				
				// All with premium marked in form leave blank with fadeOut.
				$('.ff-scheme-with-premium-blank').fadeTo(250, 0.45);
				$('.ff-scheme-with-premium-blank').find('input').attr('disabled','disabled');
				$('.ff-scheme-with-premium-blank > label').find('input').attr('disabled','disabled');

			});
	 
})( jQuery );
