(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	  $( window ).load(function() {
	 
	  });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	  jQuery(document).ready(function($) {
	 

		// copy the text in input field when clicked
		$('body').on('click', 'input.faq-fetch-add-search-input', function(e){
			
			var textBox = document.getElementById("faq-fetch-add-search-input");
			textBox.select();
			document.execCommand("copy");
					$('.faq-fetch-add-search-copy').addClass('copied');

		});

		// copy the text in input field when clicked
		$('body').on('click', 'input.faq-fetch-add-accordion-input', function(e){
			
			var textBox = document.getElementById("faq-fetch-add-accordion-input");
			textBox.select();
			document.execCommand("copy");
					$('.faq-fetch-add-accordion-copy').addClass('copied');

		});


		// when checkbox is checked, hide orderby fields. Show orderby fields when faq_category is 0
		$(".faq-fetch-add-checkbox").change(function(){
			if($(this).is(':checked')){
				$('.faq-fetch-add-order-by-wrapper').fadeTo(.3);
				$('#faq-fetch-add-accordion-select').prop('disabled', 'disabled');
			}
			else {
				$('.faq-fetch-add-order-by-wrapper').fadeTo(1);
				$('#faq-fetch-add-accordion-select').prop('disabled', false);
			}
		});

		// on page reload above functionality
			if($(".faq-fetch-add-checkbox").is(':checked')){
				$('.faq-fetch-add-order-by-wrapper').fadeTo(.3);
				$('#faq-fetch-add-accordion-select').prop('disabled', 'disabled');
			}
			else {
				$('.faq-fetch-add-order-by-wrapper').fadeTo(1);
				$('#faq-fetch-add-accordion-select').prop('disabled', false);
			}

		$('.faq-fetch-add-accordion-btn').click(function(){
			$('#faq-fetch-add-accordion-select').prop('disabled', false);


		});



			// on page load run initial values for each field 
			$('.ff-search-box-scheme-form-control').each(
					function(index, item) {
						// get data-field attr for input itemStyle to match in switch case with testimonial list element
						let dataField = $(item).data('field');
						let itemStyle = $(item).val();

					   switch(dataField){
						case 'Max_width' :
							$('.ff-search-admin').css({'max-width': `${itemStyle}px`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
							break;
					 case 'Field_padding' :
							 $('.ff-search-field-admin').css({'padding': `${itemStyle}px 0px ${itemStyle}px 15px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					case 'Field_border_radius' :
							$('.ff-search-field-admin').css({'border-radius': `${itemStyle}px 0 0 ${itemStyle}px`});
							$('.ff-search-div-admin').css({'border-radius':`${itemStyle}px`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						break;
					case 'Field_relative_top' :
							 $('.ff-search-field-admin').css({'top': `${itemStyle}px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					case 'Field_box_shadow' :
							$('.ff-search-field-admin').css({'box-shadow': `0 0 ${itemStyle}px 1px rgba(0,0,0, .2)`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						break;
					case 'Field_color' :
						$('body').append('<style>input.ff-search-field-admin::placeholder{color: ' + itemStyle + ' !important}</style>');
						break;
					case 'Field_bg_color' :
						$('input.ff-search-field-admin').css({'background-color':  itemStyle});
						break;
					case 'Field_line_height' :
							$('.ff-search-field-admin').css({'line-height': `${itemStyle}em`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'em');
						break;
					case 'Submit_bg_color' :
							$('.ff-search-submit-admin').css({'background-color': itemStyle});
						
						 break;
					 case 'Submit_color' :
							 $('.ff-search-submit-admin > span').css({'color': itemStyle});
						 break;
					 case 'Submit_padding' :
							 $('.ff-search-submit-admin').css({'padding': `${itemStyle}px 0px ${itemStyle}px 0px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					 case 'Submit_border_radius' :
							$('.ff-search-submit-admin').css({'border-radius': `0 ${itemStyle}px ${itemStyle}px 0`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						break;
					 case 'Submit_relative_top' :
							 $('.ff-search-submit-admin').css({'top': `${itemStyle}px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					 case 'Submit_line_height' :
							$('.ff-search-submit-admin').css({'line-height': `${itemStyle}em`});
							$(this).parent().children('.ff-search-box-reading').text(`${itemStyle}em`);
						break;
					 case 'Messages_color' :
							$('.ff-search-msg-admin').css({'color': itemStyle});
							
						break;
					 case 'Messages_font_size' :
							$('.ff-search-msg-admin > p').css({'font-size': `${itemStyle}px`});
							$(this).parent().children('.ff-search-box-reading').text(`${itemStyle}px`);
						break;
						
					 default :
						 break;
					   }


					   // use hover affects when page is loaded
					   var bg_hover = $('#ff-search-submit-bg-hover').val();		
					   var bg = $('#ff-search-submit-bg').val();
				 
					   $('.ff-search-submit-admin').hover(function(){
							$(this).css({'background-color': bg_hover });
					   
						}, function(){
						
							 $(this).css({'background-color': bg });
						
						});
	   
	   					// use hover affects when page is loaded
					   var text_hover = $('#ff-search-submit-text-hover').val();		
					   var text = $('#ff-search-submit-text').val();
				 
					   $('.ff-search-submit-admin').hover(function(){
							$(this).children().css({'color': text_hover });
					   
						}, function(){
						
							$(this).children().css({'color': text });
						
						});
					});
		
			// input itemStyle change and adjust element's style
			$('.ff-search-box-scheme-form-control').on('input',
				function() {
				
				// get data-field attr for input itemStyle to match in switch case with testimonial list element
				let dataField = $(this).data('field');
				let itemStyle = $(this).val();
				switch(dataField){
					case 'Max_width' :
							$('.ff-search-admin').css({'max-width': `${itemStyle}px`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
							break;
					 case 'Field_padding' :
							 $('.ff-search-field-admin').css({'padding': `${itemStyle}px 0px ${itemStyle}px 15px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					case 'Field_border_radius' :
							$('.ff-search-field-admin').css({'border-radius':`${itemStyle}px 0 0 ${itemStyle}px`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						break;
					case 'Field_relative_top' :
							 $('.ff-search-field-admin').css({'top': `${itemStyle}px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					case 'Field_box_shadow' :
							$('.ff-search-field-admin').css({'box-shadow': `0 0 ${itemStyle}px 1px rgba(0,0,0, .2)`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						break;
					case 'Field_color' :
						$('body').append('<style>input.ff-search-field-admin::placeholder{color: ' + itemStyle + ' !important}</style>');
						break;
					case 'Field_bg_color' :
						$('input.ff-search-field-admin').css({'background-color':  itemStyle});
						break;
					case 'Field_line_height' :
							$('.ff-search-field-admin').css({'line-height': `${itemStyle}em`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'em');
						break;
					case 'Submit_bg_color' :
							$('.ff-search-submit-admin').css({'background-color': itemStyle});
						
						 break;
					 case 'Submit_color' :
							 $('.ff-search-submit-admin > span').css({'color': itemStyle});
						 break;
					 case 'Submit_padding' :
							 $('.ff-search-submit-admin').css({'padding': `${itemStyle}px 0px ${itemStyle}px 0px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					 case 'Submit_border_radius' :
							$('.ff-search-submit-admin').css({'border-radius': `0 ${itemStyle}px ${itemStyle}px 0`});
							$(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						break;
					 case 'Submit_relative_top' :
							 $('.ff-search-submit-admin').css({'top': `${itemStyle}px`});
							 $(this).parent().children('.ff-search-box-reading').text(itemStyle + 'px');
						 break;
					 case 'Submit_line_height' :
							$('.ff-search-submit-admin').css({'line-height': `${itemStyle}em`});
							$(this).parent().children('.ff-search-box-reading').text(`${itemStyle}em`);
						break;
					 case 'Messages_color' :
							$('.ff-search-msg-admin').css({'color': itemStyle});
							
						break;
					 case 'Messages_font_size' :
							$('.ff-search-msg-admin > p').css({'font-size': `${itemStyle}px`});
							$(this).parent().children('.ff-search-box-reading').text(`${itemStyle}px`);
						break;
					 case  'default' :
						break;
				
				}


				// use hover affects when page is loaded
				var bg_hover = $('#ff-search-submit-bg-hover').val();		
				var bg = $('#ff-search-submit-bg').val();
		  
				$('.ff-search-submit-admin').hover(function(){
					 $(this).css({'background-color': bg_hover });
				
				 }, function(){
				 
				 	 $(this).css({'background-color': bg });
				 
				 });



				// use hover affects when page is loaded
				var text_hover = $('#ff-search-submit-text-hover').val();		
				var text = $('#ff-search-submit-text').val();
		  
				$('.ff-search-submit-admin').hover(function(){
					 $(this).children().css({'color': text_hover });
				
				 }, function(){
				 
					 $(this).children().css({'color': text });
				 
				 });
	
	
	
				}); // end of .on function
	

	  });
	 
})( jQuery );
