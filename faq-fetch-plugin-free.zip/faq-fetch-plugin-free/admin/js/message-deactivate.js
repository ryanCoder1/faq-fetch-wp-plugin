jQuery(document).ready(function($) {
	 
    $('[data-slug="faq-fetch"] .deactivate > a').on('click', function(event){
        event.preventDefault()
        var urlRedirect = document.querySelector('[data-slug="faq-fetch"] .deactivate > a').getAttribute('href');
        if (confirm('Click OK if you are upgrading to the premium version so FaQs are saved.')) {

            //save variable to database for uninstalment procedures. Set to true!
            $.ajax({
				url: ajaxurl_arr_admin.ajax_url,
				type: 'POST',
				data: {
					'action': 'uninstall_check_ff_true',
					'data': { save_ff_database: true, nonce : ajaxurl_arr_admin.nonce}
				},
				success:function(data) {

                    if(data.success === 'true'){
                        window.location.href = urlRedirect;
                    }

                }
            });
           
        } else {
             //save variable to database for uninstalment procedures. Set to false!
             $.ajax({
				url: ajaxurl_arr_admin.ajax_url,
				type: 'POST',
				data: {
					'action': 'uninstall_check_ff_false',
					'data': { save_ff_database: false, nonce : ajaxurl_arr_admin.nonce}
				},
				success:function(data) {

                    if(data.success === 'true'){
                        window.location.href = urlRedirect;
                    }

                }
            });
        }
    });
});