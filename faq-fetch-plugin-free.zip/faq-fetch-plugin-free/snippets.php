<?php

function my_layout_shortcode() {
    ob_start();
    echo do_shortcode('[et_pb_section global_module="123" fullwidth="on" specialty="off" _builder_version="3.19.18"][et_pb_row _builder_version="3.19.18"][et_pb_column type="4_4" _builder_version="3.19.18"][et_pb_text _builder_version="3.19.18"]
    ' . do_shortcode('[et_pb_layout css=".my-layout"]') . '
    [/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]');
    return ob_get_clean();
}
add_shortcode('my_layout', 'my_layout_shortcode');
?>