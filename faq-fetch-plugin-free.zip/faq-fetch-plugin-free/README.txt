=== FaQ Fetch ===
Contributors: Ryan Lackey
Tags: comments, spam
Requires at least: 4.7
Tested up to: 6.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Demo link: 

https://www.newjourneydesigns.com/?project=faq-fetch-wp-plugin

Faq Fetch is an ajax run FaQ search plugin. Shows answers to questions published and saves questions that don't have a match. 

== Description ==

The Faq Fetch Wordpress Plugin is easier to explain saying all the features.
The plugin works with a search box shortcode and an output shortcode to use in any theme and theme builder in wordpress. 
The search box is ran by ajax which gives an immediate result on the screen.
An email is sent to the preferred email address when a new question is asked and a link is provided back to the dashboard for quick access. 
Fully styleable, like a theme builder, search box and accordion section. You make your own style. 
Questions that are asked are saved within the post edit but to start off it's suggested that you add your own basic FaQ questions and answers.
If there is a duplicate question from a search, a "Time Searched" column keeps count for popular questions.
The search box has messages that give heads up about the question will be answered soon.  
FaQ questions are added as a post 'draft' waiting to be published with an answer. 
FaQ posts if not wanted can be sent to trash but will restart if questioned again. Keeping a question as a 'draft' is ok and times searched can say if it's popular within time. 

== Installation ==

To install, use the zip file and upload it to the Plugin section of a Wordpress website. 

Once you have the zip file go ahead and upload it into the WordPress CMS Plugin area.
The plugin is preloaded with a Search Box and Accordion-styled designs that are easy to follow.
The Accordion won't show on the front end page if there aren't any FaQ questions and answers to show. 
The FaQ has to have a Question and Answer and be a published status. If categories are chosen then there must be a category selected for each FaQ to show.

FaQ Search page:

This is the Faq search page in the dashboard. As you can see there is a notice up top that states to add an email address before going any further. Above the box to enter the email there is a note to add a SMTP service. This is very important so all the emails get sent out correctly. 
Below that is make shortcode for accordion. You have a few different selections. First you can use faq categories by moving this circle to the right for the categories to show. From here the other option to choose is the Order with a Ascending or descending selections. Now if the categories are turned off there are a few more accordion display options. In the Order by there is order by Id, title, and date. The times searched is for the order to be most popular searched faq questions so this way you can have most searched questions up top and vice versa by adjusting the Order selection. once the selection is set click the make accordion shortcode button and a new shortcode is designed. 
The Active shortcode for search box doesn't change. So use the faq fetch search shortcode when ready. 


FaQ Fetch Accordion / Search Box pages:


This is the Accordion Scheme page. Before any new styles are made there is a default style set up on the right. It shows a category and two Faq questions and answers within that category.
On the left side where it says styles to choose there are multiple ways to adjust the styles of the accordion. There are padding selections that expand the element that it is meant for. Both the category and accordion label have padding and that is what it looks like when adjusted. 
There are background colors that you can adjust. They can be switched off for no color or kept on for the design you're looking for. The background colors are for the category, the accordion label, and the content area. The accordion label also has a background color hover affect. Just adjust to the color you want and the hover affect is in effect. 
The styles also have a font size and font color options to choose from. These work in each of the category, accordion label, and the content area. You can mix and match the colors to your liking. 
The border radius or round corners are another option. This feature is included in the categories, accordion label, and content area. Allowing for all the versatility in designs depending on what the website is looking to accomplish with styles. 
There are border styles for the accordion label. There are two ways to get a border to show and one is the border color and the next is the border width. The border width has to be set to a number value for it to show. 
There are a few margins to style with. The margins will add a gap to the top and bottom of the accordion labels. Just adjust the margin and decide on the look you want for the design. 

once through with all you're selections go ahead to the blue save accordion design button and save your design. It shows immediately on the page here and on the front end with a page refresh the new design will show. 

So enjoy your styling! 



Search Box Scheme page


This is the Search box Scheme page. Before any new styles are made there is a default style set up on the right. It shows a search box with search button.
On the left side where it says styles to choose there are multiple ways to adjust the styles of the search box. There are padding selections that expand the element that it is meant for. Both the search input field and search button have padding and that is what it looks like when adjusted. 
There are background colors that you can adjust.  The background colors are for the search input field and search button. The search button also has a background color hover affect. Just adjust to the color you want and the hover affect is in effect. 
The styles also have a font color option to choose from. These work in the search input field and search button. You can mix and match the colors to your liking. 
The border radius or round corners are another option. This feature is included in the the search input field and search button. Allowing for all the versatility in designs depending on what the website is looking to accomplish with styles. 
There are border styles for the the search input field and search button. There are two ways to get a border to show and one is the border color and the next is the border width. The border width has to be set to a number value for it to show. 
There is a box shadow for the input search field. It is set to a specific color and just the blur is adjusted for the effect you want. 
The line height feature lets you adjust the space around the text. You can see how it adjust the element almost like a padding. 
The up / down options let you move each element up and down. 
There are sometimes when what you're seeing in the search box scheme page isn't exactly positioned correctly on the front end. Styles can get overridden on the front end so the search box page might have to be adjusted to succeed those styles. 

once through with all you're selections go ahead to the blue save accordion design button and save your design. It shows immediately on the page here and on the front end with a page refresh the new design will show. 
So enjoy your styling! 


== Changelog ==




Initial version 1.0.0


======================


